#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🔥 Bulk SMS Sender Bot
=====================
A Telegram bot that sends bulk SMS to vehicle owners using Firebase-connected
SMS gateway phones (same backend used by the Auto Token bot).

Features
--------
- User uploads a .txt / .csv file of "Vehicle Number, Mobile Number"
- User creates and saves multiple message Templates with placeholders
- User adds one or many Firebase projects (Public / Private / Service Account)
- User selects a Firebase, the bot auto-filters ONLY online gateway phones
- One tap "Send Bulk SMS" -> template is auto-filled per vehicle & sent
- Each online gateway phone is limited to 100 SMS per day, then the bot
  automatically switches to the next online phone (round-robin by lowest usage).

Run
---
  pip install -r requirements.txt
  put your bot token in settings.json (telegramAutoBotToken/telegramBotToken)
  python bulk_sms_bot.py
"""

import asyncio
import contextlib
import copy
import csv
import html
import io
import json
import logging
import os
import re
import signal
import sqlite3
import sys
import threading
import time
import urllib.parse
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Set, Tuple

try:
    import google.auth.transport.requests
    from google.oauth2 import service_account
    HAS_GOOGLE_AUTH = True
except ImportError:
    HAS_GOOGLE_AUTH = False

import requests
from telegram import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
    Update,
)
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

# ===================== CONFIG =====================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SETTINGS_FILE = os.path.join(BASE_DIR, "settings.json")
DB_FILE = os.path.join(BASE_DIR, "bot_data.db")

BOT_TOKEN = ""
CHANNEL_USERNAME = ""
CHANNEL_TITLE = ""
CHANNEL_LINK = ""
ADMIN_IDS: List[int] = []


def _load_settings_file() -> dict:
    try:
        if os.path.isfile(SETTINGS_FILE):
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception as e:
        print(f"settings.json load warning: {e}")
    return {}


def _first_str(*vals) -> str:
    for v in vals:
        if v is None:
            continue
        s = str(v).strip()
        if s:
            return s
    return ""


def reload_runtime_config() -> dict:
    global BOT_TOKEN, CHANNEL_USERNAME, CHANNEL_TITLE, CHANNEL_LINK, ADMIN_IDS
    global OWNER_USERNAME, OWNER_NAME
    cfg = _load_settings_file()

    BOT_TOKEN = _first_str(
        os.environ.get("BOT_TOKEN"),
        os.environ.get("TELEGRAM_AUTO_BOT_TOKEN"),
        cfg.get("telegramAutoBotToken"),
        cfg.get("telegramBotToken"),
        cfg.get("bot_token"),
    )

    CHANNEL_USERNAME = _first_str(
        os.environ.get("CHANNEL_USERNAME"),
        cfg.get("channel_username"),
        cfg.get("channelUsername"),
    )
    CHANNEL_TITLE = _first_str(os.environ.get("CHANNEL_TITLE"), cfg.get("channel_title"))
    CHANNEL_LINK = _first_str(os.environ.get("CHANNEL_LINK"), cfg.get("channel_link"))

    OWNER_USERNAME = _first_str(os.environ.get("OWNER_USERNAME"), cfg.get("owner_username")) or "@NUCLEARSDDOSOWNER"
    OWNER_NAME = _first_str(os.environ.get("OWNER_NAME"), cfg.get("owner_name")) or "NUCLEAR"

    admin_cfg = cfg.get("admin_ids")
    if isinstance(admin_cfg, list):
        admin_raw = ",".join(str(x) for x in admin_cfg if str(x).strip().isdigit())
    else:
        admin_raw = _first_str(admin_cfg)
    admin_raw = _first_str(os.environ.get("ADMIN_IDS"), admin_raw)
    ADMIN_IDS = [int(x.strip()) for x in admin_raw.split(",") if x.strip().isdigit()]

    return {
        "bot_token_set": bool(BOT_TOKEN),
        "admins": ADMIN_IDS[:],
        "channel": CHANNEL_USERNAME or "",
    }


reload_runtime_config()

DEFAULT_USER_CONFIG = {
    "firebase_list": [],                # [{url, secret, service_account, added_at}]
    "active_firebase_index": 0,
    "selected_firebase_indexes": [],    # multi-select — online devices from all these combined
    "vehicle_file": None,               # {name, rows:[{...}], total, parsed_at}
    "templates": [],                    # [{name, text, created_at}]
    "active_template_index": 0,
    "last_send_summary": None,
    "subscription": None,               # {until, plan, granted_at, by}
}

# Conversation states
MAIN_MENU = 0
AWAIT_PUBLIC_FIREBASE = 1
AWAIT_PRIVATE_FIREBASE = 2
AWAIT_FIREBASE_SECRET = 3
AWAIT_TEMPLATE_NAME = 4
AWAIT_TEMPLATE_TEXT = 5
AWAIT_APPROVE_ID = 6
AWAIT_REVOKE_ID = 7

DAILY_LIMIT_PER_DEVICE = 100
SEND_DELAY = 0.05
MAX_FILE_ROWS = 200_000
MAX_TEMPLATE_CHARS = 2000
TG_PREVIEW_CHARS = 1800  # keep Telegram replies under the 4096 cap

# Subscription plans key -> (days, label)
SUB_PLANS = {
    "day": (1, "1 Day"),
    "3days": (3, "3 Days"),
    "week": (7, "1 Week"),
    "month": (30, "1 Month"),
    "3months": (90, "3 Months"),
}
SUB_FMT = "%Y-%m-%d %H:%M:%S"
OWNER_USERNAME = "@NUCLEARSDDOSOWNER"
OWNER_NAME = "NUCLEAR"

# ===================== DB + CACHE =====================
user_cache: Dict[str, dict] = {}
banned_set: Set[str] = set()
cache_lock = threading.RLock()


def init_db():
    conn = None
    try:
        conn = sqlite3.connect(DB_FILE, timeout=10)
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id     TEXT PRIMARY KEY,
                config      TEXT NOT NULL,
                updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS banned (
                user_id     TEXT PRIMARY KEY,
                banned_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS sms_usage (
                firebase_url  TEXT NOT NULL,
                device_id     TEXT NOT NULL,
                day           TEXT NOT NULL,
                count         INTEGER DEFAULT 0,
                updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (firebase_url, device_id, day)
            )
        """)
        cur.execute("PRAGMA journal_mode=WAL")
        conn.commit()
    except Exception as e:
        logging.getLogger(__name__).error(f"init_db error: {e}")
    finally:
        if conn:
            conn.close()


def load_cache():
    global user_cache, banned_set
    with cache_lock:
        user_cache.clear()
        banned_set.clear()

        conn = None
        try:
            conn = sqlite3.connect(DB_FILE, timeout=10)
            cur = conn.cursor()
            cur.execute("SELECT user_id, config FROM users")
            for uid, conf in cur.fetchall():
                try:
                    cfg = json.loads(conf)
                    for k, v in DEFAULT_USER_CONFIG.items():
                        if k not in cfg:
                            cfg[k] = copy.deepcopy(v)
                    user_cache[uid] = cfg
                except Exception:
                    continue
            cur.execute("SELECT user_id FROM banned")
            for (uid,) in cur.fetchall():
                banned_set.add(uid)
        except Exception as e:
            logging.getLogger(__name__).error(f"load_cache DB error: {e}")
        finally:
            if conn:
                conn.close()


def get_user_config(user_id: int) -> dict:
    uid = str(user_id)
    with cache_lock:
        if uid in user_cache:
            return copy.deepcopy(user_cache[uid])
        cfg = copy.deepcopy(DEFAULT_USER_CONFIG)
        user_cache[uid] = copy.deepcopy(cfg)
    _save_to_db(uid, cfg)
    return cfg


def save_user_config(user_id: int, cfg: dict):
    uid = str(user_id)
    with cache_lock:
        user_cache[uid] = copy.deepcopy(cfg)
    _save_to_db(uid, cfg)


def _save_to_db(uid: str, cfg: dict):
    try:
        conn = sqlite3.connect(DB_FILE, timeout=10)
        cur = conn.cursor()
        cur.execute(
            "INSERT OR REPLACE INTO users (user_id, config, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)",
            (uid, json.dumps(cfg, ensure_ascii=False)),
        )
        conn.commit()
        conn.close()
    except Exception as e:
        logging.getLogger(__name__).error(f"DB save failed: {e}")


def is_banned(user_id: int) -> bool:
    return str(user_id) in banned_set


def ban_user(user_id: int):
    with cache_lock:
        banned_set.add(str(user_id))
    try:
        conn = sqlite3.connect(DB_FILE)
        cur = conn.cursor()
        cur.execute("INSERT OR REPLACE INTO banned (user_id) VALUES (?)", (str(user_id),))
        conn.commit()
        conn.close()
    except Exception as e:
        logging.getLogger(__name__).error(f"Ban error: {e}")


def unban_user(user_id: int):
    with cache_lock:
        banned_set.discard(str(user_id))
    try:
        conn = sqlite3.connect(DB_FILE)
        cur = conn.cursor()
        cur.execute("DELETE FROM banned WHERE user_id = ?", (str(user_id),))
        conn.commit()
        conn.close()
    except Exception as e:
        logging.getLogger(__name__).error(f"Unban error: {e}")


def get_banned_users() -> List[str]:
    with cache_lock:
        return sorted(list(banned_set))


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


# ===================== SUBSCRIPTION =====================
def get_subscription(cfg: dict) -> dict:
    """Returns {active, until, days_left, plan} for a user config."""
    sub = cfg.get("subscription") if isinstance(cfg, dict) else None
    if not isinstance(sub, dict) or not sub.get("until"):
        return {"active": False, "until": None, "days_left": 0, "plan": None}
    try:
        until = datetime.strptime(str(sub["until"])[:19], SUB_FMT)
    except Exception:
        return {"active": False, "until": None, "days_left": 0, "plan": None}
    seconds = (until - datetime.now()).total_seconds()
    return {"active": seconds > 0, "until": until, "days_left": seconds / 86400.0, "plan": sub.get("plan")}


def set_subscription(cfg: dict, days: int, plan_label: str, by) -> datetime:
    until = datetime.now() + timedelta(days=int(days))
    cfg["subscription"] = {
        "until": until.strftime(SUB_FMT),
        "plan": plan_label,
        "granted_at": datetime.now().strftime(SUB_FMT),
        "by": str(by),
    }
    return until


def revoke_subscription(cfg: dict):
    cfg["subscription"] = {
        "until": "2000-01-01 00:00:00",
        "plan": "Revoked",
        "granted_at": datetime.now().strftime(SUB_FMT),
        "by": "revoke",
    }


def subscription_status_text(cfg: dict, username: str = "") -> str:
    sub = get_subscription(cfg)
    if sub["active"]:
        left = max(0, int(sub["days_left"]))
        rest = f" {min(23, left)} days remaining" if left > 0 else ""
        return (
            f"🔐 <b>Subscription: ✅ Active</b>\n"
            f"📅 Till: <code>{sub['until'].strftime('%Y-%m-%d')}</code> ({left} days left)\n"
            f"📦 Plan: {sub.get('plan') or '-'}"
        )
    owner = username or OWNER_USERNAME
    return (
        f"🔐 <b>Subscription: ❌ Not Active</b>\n\n"
        f"Ye bot sirf <b>approved members</b> ke liye hai.\n"
        f"Access ke liye owner se baat karein: <b>{owner}</b>"
    )


def get_sub_keyboard():
    return ReplyKeyboardMarkup([[KeyboardButton("🔄 Check Status")]], resize_keyboard=True)


async def require_access(update: Update, context: ContextTypes.DEFAULT_TYPE, check_sub: bool = True) -> bool:
    user_id = update.effective_user.id
    if is_banned(user_id) and not is_admin(user_id):
        if update.message:
            await update.message.reply_text("🚫 You are banned.")
        elif update.callback_query:
            await update.callback_query.answer("You are banned.", show_alert=True)
        return False
    if is_admin(user_id):
        return True
    if CHANNEL_USERNAME:
        try:
            member = await context.bot.get_chat_member(CHANNEL_USERNAME, user_id)
            ok = member.status not in ("left", "kicked")
        except Exception:
            ok = True
        if not ok:
            title = CHANNEL_TITLE or CHANNEL_USERNAME
            link = CHANNEL_LINK or (f"https://t.me/{CHANNEL_USERNAME.lstrip('@')}" if CHANNEL_USERNAME.lstrip("@") else "")
            msg = f"🚫 Join [{title}]({link}) first." if link else f"🚫 Join {title} first."
            if update.callback_query:
                await update.callback_query.answer("Join channel first!", show_alert=True)
            elif update.message:
                await update.message.reply_text(msg, parse_mode=ParseMode.MARKDOWN, disable_web_page_preview=True)
            return False
    if check_sub:
        cfg = get_user_config(user_id)
        if not get_subscription(cfg)["active"]:
            if update.callback_query:
                await update.callback_query.answer("No active subscription!", show_alert=True)
            elif update.message:
                await update.message.reply_text(
                    subscription_status_text(cfg),
                    parse_mode=ParseMode.HTML,
                    reply_markup=get_sub_keyboard(),
                )
            return False
    return True


# ===================== FIREBASE HELPERS =====================
FIREBASE_SCOPES = [
    "https://www.googleapis.com/auth/userinfo.email",
    "https://www.googleapis.com/auth/firebase.database",
]

_token_cache: Dict[str, Tuple[str, float]] = {}


def get_service_account_token(sa_info: dict) -> Optional[str]:
    if not HAS_GOOGLE_AUTH or not isinstance(sa_info, dict):
        return None
    try:
        client_email = sa_info.get("client_email", "")
        if not client_email:
            return None
        now = time.time()
        if client_email in _token_cache:
            token, expiry = _token_cache[client_email]
            if now < expiry - 60:
                return token
        creds = service_account.Credentials.from_service_account_info(
            sa_info, scopes=FIREBASE_SCOPES
        )
        req = google.auth.transport.requests.Request()
        creds.refresh(req)
        if creds.token:
            expiry = creds.expiry.timestamp() if creds.expiry else (now + 3500)
            _token_cache[client_email] = (creds.token, expiry)
            return creds.token
    except Exception as e:
        logging.getLogger(__name__).error(f"Error refreshing service account token: {e}")
    return None


def normalize_firebase_base(url: str) -> str:
    url = (url or "").strip()
    if not url:
        return ""
    try:
        parsed = urllib.parse.urlparse(url)
        if not (parsed.scheme and parsed.netloc):
            return url.rstrip("/")
        path = (parsed.path or "").rstrip("/")
        if path.endswith(".json"):
            path = path[:-5].rstrip("/")
        for leaf in ("/clients", "/devices", "/messages", "/deviceMessages", "/.json"):
            if path.endswith(leaf):
                path = path[: -len(leaf)].rstrip("/")
        return f"{parsed.scheme}://{parsed.netloc}{path}".rstrip("/")
    except Exception:
        return url.rstrip("/")


def parse_firebase_input(text: str) -> Tuple[str, str]:
    text = (text or "").strip()
    try:
        parsed = urllib.parse.urlparse(text)
        if parsed.scheme and parsed.netloc:
            qs = urllib.parse.parse_qs(parsed.query)
            secret = (qs.get("auth") or qs.get("access_token") or [""])[0].strip()
            clean_base = normalize_firebase_base(f"{parsed.scheme}://{parsed.netloc}{parsed.path}")
            return clean_base, secret
    except Exception:
        pass
    return normalize_firebase_base(text), ""


def clean_database_secret(raw: str) -> str:
    s = (raw or "").strip()
    if not s:
        return ""
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        s = s[1:-1].strip()
    if s.lower().startswith("auth="):
        s = s.split("=", 1)[1].strip()
    if s.startswith("http://") or s.startswith("https://"):
        _, sec = parse_firebase_input(s)
        if sec:
            return sec
    if "\n" in s:
        for line in s.splitlines():
            line = line.strip()
            if line and not line.lower().startswith(("database", "secret", "http")):
                s = line
                break
    return s.strip()


def validate_firebase_url(url: str) -> bool:
    u = (url or "").strip()
    if not u.startswith(("https://", "http://")):
        return False
    try:
        host = urllib.parse.urlparse(u).netloc
    except Exception:
        return True
    return bool(host)


def parse_service_account_dict(data: dict) -> Tuple[bool, Optional[str], Optional[str], Optional[str]]:
    if not isinstance(data, dict):
        return False, None, None, "Invalid JSON data."
    if "project_info" in data and "client" in data:
        proj = data.get("project_info", {})
        return False, proj.get("project_id"), None, (
            "⚠️ Ye `google-services.json` (Android app config) hai.\n\n"
            "**Firebase Admin SDK Service Account** JSON chahiye:\n"
            "1. Firebase Console ➔ **Project Settings (⚙️)**\n"
            "2. **Service accounts** tab\n"
            "3. **Generate new private key**\n"
            "4. Jo `.json` download ho wo yahan upload karein."
        )
    if data.get("type") == "service_account" and data.get("private_key"):
        project_id = data.get("project_id")
        if not project_id:
            return False, None, None, "Missing `project_id` in Service Account JSON."
        return True, project_id, f"https://{project_id}-default-rtdb.firebaseio.com", None
    return False, None, None, "Ye valid Firebase Service Account JSON nahi hai."


async def extract_json_from_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> Tuple[Optional[dict], Optional[str]]:
    msg = update.message
    if not msg:
        return None, None
    if msg.document:
        try:
            file = await context.bot.get_file(msg.document.file_id)
            content_bytes = await file.download_as_bytearray()
            content_str = content_bytes.decode("utf-8", errors="ignore").strip()
            return json.loads(content_str), None
        except json.JSONDecodeError:
            return None, "Uploaded file is not valid JSON."
        except Exception as e:
            return None, f"Failed to read file: {e}"
    text = (msg.text or "").strip()
    if text.startswith("{") and text.endswith("}"):
        try:
            return json.loads(text), None
        except json.JSONDecodeError:
            return None, "Invalid JSON text format."
    return None, None


def get_firebase_request_params(entry: dict, path: str) -> Tuple[str, dict]:
    base = normalize_firebase_base((entry or {}).get("url", "") or "")
    if not base:
        return "", {}
    url = f"{base}/{path.lstrip('/')}"
    headers: dict = {}
    params: dict = {}
    sa_info = entry.get("service_account")
    if sa_info and isinstance(sa_info, dict) and sa_info.get("private_key"):
        token = get_service_account_token(sa_info)
        if token:
            params["access_token"] = token
            headers["Authorization"] = f"Bearer {token}"
    else:
        secret = clean_database_secret(entry.get("secret", "") or "")
        if secret and not secret.startswith("AIza"):
            params["auth"] = secret
    if params:
        sep = "&" if "?" in url else "?"
        url = f"{url}{sep}{urllib.parse.urlencode(params)}"
    return url, headers


def fetch_json(url: str, headers: dict = None, retries: int = 2, timeout: int = 10) -> dict:
    for attempt in range(retries + 1):
        try:
            r = requests.get(url, headers=headers or {}, timeout=timeout)
            if r.status_code == 200:
                txt = r.text.strip()
                return {} if txt == "null" else r.json()
            if r.status_code >= 500 and attempt < retries:
                time.sleep(0.4)
                continue
            return {}
        except requests.exceptions.Timeout:
            if attempt == retries:
                logging.getLogger(__name__).warning(f"Timeout fetching {url}")
            else:
                time.sleep(0.3)
        except requests.exceptions.ConnectionError:
            if attempt == retries:
                logging.getLogger(__name__).warning(f"Connection error: {url}")
            else:
                time.sleep(0.3)
        except Exception as e:
            logging.getLogger(__name__).error(f"Fetch error: {e}")
            break
    return {}


def test_firebase_auth(base_url: str, secret: str = "", service_account: Optional[dict] = None) -> Tuple[bool, str]:
    base = normalize_firebase_base(base_url)
    if not base:
        return False, "Invalid Firebase URL"
    headers, params = {}, {}
    sa = service_account if isinstance(service_account, dict) else None
    if sa and sa.get("private_key"):
        token = get_service_account_token(sa)
        if not token:
            return False, "Service Account se token nahi bana (google-auth check karein)"
        params["access_token"] = token
        headers["Authorization"] = f"Bearer {token}"
    else:
        sec = clean_database_secret(secret)
        if not sec:
            return False, "Database Secret empty hai"
        if sec.startswith("AIza"):
            return False, "Ye Web API Key (AIza...) hai — RTDB private access isse nahi hota. Service accounts ➔ Database secrets use karein."
        params["auth"] = sec
    try:
        r = requests.get(f"{base}/.json", params=params, headers=headers, timeout=15)
        if r.status_code == 200:
            return True, "Connected"
        if r.status_code in (401, 403):
            return False, "Permission denied — Secret / Service Account galat hai ya match nahi karta."
        if r.status_code == 404:
            return False, "Firebase URL not found (404)."
        return False, f"HTTP {r.status_code}: {(r.text or '')[:140]}"
    except requests.exceptions.Timeout:
        return False, "Firebase timeout — dubara try karein"
    except requests.exceptions.ConnectionError:
        return False, "Firebase unreachable — URL check karein"
    except Exception as e:
        return False, f"Connection error: {e}"


def _to_ms_ts(val) -> Optional[float]:
    try:
        fv = float(val)
    except Exception:
        return None
    if fv < 1e12:
        fv *= 1000.0
    return fv


def is_device_online(data: dict, now_ms: float = None) -> bool:
    if not isinstance(data, dict):
        return False
    if now_ms is None:
        now_ms = time.time() * 1000
    if data.get("isOnline") or data.get("online") or data.get("connected"):
        return True
    st = data.get("status")
    if st is True or st == 1 or st is False:
        return st is True or st == 1
    if isinstance(st, str) and st.strip().lower() in ("online", "active", "alive", "on", "true", "1", "connected"):
        return True
    if isinstance(st, (int, float)) and st != 0:
        return True
    window = 900_000.0
    for key in ("lastOnlineAt", "last_seen", "lastSeen", "lastSeenAt", "updatedAt",
                "last_update", "lastUpdate", "timestamp", "ts", "last_heartbeat", "lastHeartbeat"):
        ms = _to_ms_ts(data.get(key))
        if ms is not None and -60_000 < (now_ms - ms) < window:
            return True
    hb = data.get("heartbeat")
    if isinstance(hb, dict):
        hb_st = str(hb.get("status") or "").lower()
        ms = _to_ms_ts(hb.get("timestamp") or hb.get("ts") or hb.get("time"))
        if ms is not None and (now_ms - ms) < window:
            return True
        if hb_st in ("alive", "online", "active") and ms is not None and (now_ms - ms) < window * 2:
            return True
    elif hb is not None:
        ms = _to_ms_ts(hb)
        if ms is not None and (now_ms - ms) < window:
            return True
    return False


def device_display_meta(data: dict) -> Tuple[str, str, bool]:
    if not isinstance(data, dict):
        return "", "", False
    model = (data.get("deviceModel") or data.get("modelName") or data.get("model")
             or data.get("phone_model") or data.get("device_name") or data.get("name") or "")
    phone = data.get("phoneNumber") or data.get("mobNo") or data.get("mobile") or data.get("number") or data.get("msisdn") or ""
    return str(model).strip(), str(phone).strip(), is_device_online(data)


def fetch_all_devices(entry: dict) -> Dict[str, dict]:
    merged: Dict[str, dict] = {}
    for path in ("clients.json", "devices.json"):
        url, headers = get_firebase_request_params(entry, path)
        if not url:
            continue
        blob = fetch_json(url, headers=headers, retries=2, timeout=20)
        if not isinstance(blob, dict) or not blob:
            continue
        count = 0
        for did, data in blob.items():
            if data is None or not isinstance(data, dict):
                continue
            if str(did).startswith(".") or str(did) in ("webhookEvent", "actions", "config"):
                continue
            did_s = str(did)
            if did_s in merged and isinstance(merged[did_s], dict):
                base = dict(merged[did_s])
                base.update({k: v for k, v in data.items() if v is not None})
                merged[did_s] = base
            else:
                merged[did_s] = data
            count += 1
        logging.getLogger(__name__).info(f"Firebase {path}: {count} device nodes")
    return merged


def get_online_devices(entry: dict) -> Dict[str, dict]:
    devices = fetch_all_devices(entry)
    if not devices:
        return {}
    now_ms = time.time() * 1000
    return {str(did): data for did, data in devices.items() if is_device_online(data, now_ms)}


def extract_sims(device_data: dict) -> List[dict]:
    """Active SIM cards reported by the gateway app on the device node."""
    if not isinstance(device_data, dict):
        return [{"index": 0, "label": "📶 SIM 1"}, {"index": 1, "label": "📶 SIM 2"}]
    sims_raw = (
        device_data.get("sims")
        or device_data.get("simCards")
        or device_data.get("sim_cards")
        or device_data.get("simInfo")
    )
    if sims_raw and isinstance(sims_raw, list) and len(sims_raw) > 0:
        sims = []
        for i, s in enumerate(sims_raw):
            if not isinstance(s, dict):
                continue
            idx_val = (
                s.get("simSlotIndex")
                if s.get("simSlotIndex") is not None
                else (s.get("slot") or s.get("index") or s.get("simIndex") or i)
            )
            try:
                idx = int(idx_val)
            except Exception:
                idx = i
            label = f"📶 SIM {idx + 1}"
            carrier = s.get("carrierName") or s.get("carrier") or ""
            phone = s.get("phoneNumber") or s.get("number") or s.get("msisdn") or ""
            extra = []
            if carrier and str(carrier).lower() not in ("no service", "unknown"):
                extra.append(str(carrier))
            if phone:
                extra.append(str(phone))
            if extra:
                label += f" ({', '.join(extra)})"
            sims.append({"index": idx, "label": label})
        if sims:
            return sims
    return [{"index": 0, "label": "📶 SIM 1"}, {"index": 1, "label": "📶 SIM 2"}]


def _sim_name_from_readback(d: dict) -> str:
    """Try to figure out which SIM(s) the app used from the confirmed send node."""
    if not isinstance(d, dict):
        return ""
    res = []
    for key in ("subscriptionId", "simSlot", "simSlotIndex", "slotIndex", "simIndex", "sim", "slot", "simId"):
        v = d.get(key)
        if v is None:
            continue
        try:
            n = int(v)
            if key in ("subscriptionId", "simId") and n > 1:
                n = n - 1
            res.append(f"SIM {max(0, n)}")
        except Exception:
            pass
    if res:
        return ", ".join(dict.fromkeys(res))
    for key in ("sims", "results", "simResults", "sendResults"):
        v = d.get(key)
        if not isinstance(v, list) or not v or not isinstance(v[0], dict):
            continue
        done = []
        for item in v:
            ok_any = any(item.get(k) is True or str(item.get(k, "")).lower() == "true"
                         for k in ("sent", "sended", "isSended", "sendOk", "success", "ok"))
            if ok_any:
                idx = None
                for kk in ("simSlotIndex", "simSlot", "subscriptionId", "index", "simIndex"):
                    if item.get(kk) is not None:
                        try:
                            idx = int(item[kk])
                        except Exception:
                            idx = None
                        break
                if idx is None:
                    done.append(item.get("simId") or item.get("sim") or "")
                else:
                    done.append(f"SIM {idx}")
        clean = [str(x) for x in done if x not in (None, "", "SIM ")]
        if clean:
            return ", ".join(dict.fromkeys(clean))
    return ""


_sim_map_cache: Dict[str, Tuple[str, float]] = {}


def _msg_norm(s: str) -> str:
    return " ".join((s or "").split()).strip().lower()


def _digits(s) -> str:
    return re.sub(r"\D", "", str(s or ""))


def _device_shallow_keys(entry: dict, device_id: str) -> Set[str]:
    """Message keys already present for this device (cheap shallow read)."""
    try:
        url, headers = get_firebase_request_params(entry, f"messages/{device_id}.json?shallow=true")
        if not url:
            return set()
        r = requests.get(url, headers=headers, timeout=8)
        if r.status_code != 200:
            return set()
        d = r.json()
        return set(d.keys()) if isinstance(d, dict) else set()
    except Exception:
        return set()


def _device_messages(entry: dict, device_id: str) -> Dict[str, dict]:
    try:
        url, headers = get_firebase_request_params(entry, f"messages/{device_id}.json")
        if not url:
            return {}
        r = requests.get(url, headers=headers, timeout=12)
        if r.status_code != 200:
            return {}
        d = r.json()
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _sim_slot_for_sender(entry: dict, device_id: str, sender: str) -> str:
    """Map the sender number (SIM number) back to its SIM slot via the device node."""
    cache_key = f"{entry.get('url','').rstrip('/')}::{device_id}"[:70]
    now = time.time()
    sims = None
    cached = _sim_map_cache.get(cache_key)
    if cached and now < cached[1]:
        sims = cached[0]
    else:
        try:
            url, headers = get_firebase_request_params(entry, f"clients/{device_id}.json")
            if url:
                r = requests.get(url, headers=headers, timeout=8)
                if r.status_code == 200:
                    cd = r.json()
                    if isinstance(cd, dict) and isinstance(cd.get("sims"), list):
                        sims = cd["sims"]
        except Exception:
            sims = None
        _sim_map_cache[cache_key] = (sims, now + 300)
    if not sims:
        return f"({sender})"
    want = _digits(sender)
    for s in sims:
        if isinstance(s, dict) and _digits(s.get("phoneNumber") or "") == want:
            try:
                return f"SIM {int(s.get('simSlotIndex', 0)) + 1}"
            except Exception:
                return f"({sender})"
    return f"({sender})"


def _confirm_send_readback(entry: dict, send_paths: List[str], cmd_id: int, device_id: str,
                           msg_norm: str, baseline: Dict[str, Set[str]],
                           max_wait: float = 6.0) -> Tuple[str, str]:
    """Verify an SMS actually went out.
    Strategy:
      1. sendSms node gets DELETED / cleared by the phone  (= command consumed)
      2. sendSms node flips isSended/sendOk -> True        (phone acknowledged)
      3. /messages/{device_id} gains an entry with type=outgoing & our text
         (extra proof the SMS left the SIM — 'sender' reveals which SIM was used)
    Returns (verdict, sim_info)."""
    entries = baseline.setdefault(device_id, set())
    start = time.time()
    while time.time() - start < max_wait:
        time.sleep(0.9)
        # 1) sendSms node status
        for path in send_paths:
            try:
                url, headers = get_firebase_request_params(entry, path)
                if not url:
                    continue
                r = requests.get(url, headers=headers, timeout=5)
                if r.status_code != 200:
                    continue
                d = r.json()
                # node deleted / emptied -> the phone consumed this command
                if d is None or (isinstance(d, dict) and not d):
                    return "confirmed", ""
                if not isinstance(d, dict):
                    continue
                node_cmd = d.get("cmdId")
                if node_cmd is not None and str(node_cmd) != str(cmd_id):
                    continue
                sended = d.get("isSended") is True or str(d.get("isSended", "")).lower() == "true"
                send_ok = d.get("sendOk") is True or str(d.get("sendOk", "")).lower() == "true"
                if sended or send_ok:
                    sim = _sim_name_from_readback(d)
                    if not sim:
                        sim = ""
                    return "confirmed", sim
            except Exception:
                continue
        # 2) messages log — new outgoing entry matching our message
        msgs = _device_messages(entry, device_id)
        if msgs:
            new_keys = set(msgs.keys()) - entries
            for k in new_keys:
                m = msgs[k]
                if not isinstance(m, dict):
                    continue
                sender = m.get("sender") or ""
                if str(m.get("type", "")).lower() == "outgoing" and _msg_norm(m.get("message")) == msg_norm:
                    sim = _sim_slot_for_sender(entry, device_id, sender) if sender else ""
                    return "confirmed", sim
            entries |= set(msgs.keys())
        else:
            entries = baseline.setdefault(device_id, set())
    return "unconfirmed", ""


def _send_sms_sync(entry: dict, device_id: str, to: str, msg: str,
                   baseline: Dict[str, Set[str]], confirm_wait: float = 6.0) -> Tuple[bool, str]:
    device_id = str(device_id or "").strip()
    if not device_id:
        return False, "No device"
    baseline = baseline or {}
    if device_id not in baseline:
        baseline[device_id] = _device_shallow_keys(entry, device_id)
    sim = 0
    cmd_id = int(time.time() * 1000)
    payload_simple = {"cmdId": cmd_id, "from": sim, "to": to.strip(), "message": msg.strip(), "isSended": False}
    payload_cmd = {"cmdId": cmd_id, "from": sim, "to": to.strip(), "message": msg.strip(),
                   "isSended": False, "sendOk": False}
    attempts = [
        (f"clients/{device_id}/webhookEvent/sendSms.json", payload_simple),
        (f"devices/{device_id}/webhookEvent/sendSms.json", payload_simple),
        (f"devices/{device_id}/actions/sendSms.json", payload_cmd),
        (f"clients/{device_id}/actions/sendSms.json", payload_cmd),
    ]
    last_err = "No URL"
    for path, payload in attempts:
        url, headers = get_firebase_request_params(entry, path)
        if not url:
            continue
        try:
            r = requests.put(url, headers=headers, json=payload, timeout=8)
            if 200 <= r.status_code < 300:
                send_paths = [p for (p, _) in attempts]
                verdict, sim_info = _confirm_send_readback(entry, send_paths, cmd_id, device_id,
                                                           _msg_norm(msg), baseline, max_wait=confirm_wait)
                detail = "OK (queued, unconfirmed)"
                if verdict == "confirmed":
                    detail = "OK (phone-confirmed)"
                    if sim_info:
                        detail += f" | {sim_info}"
                if device_id not in baseline:
                    baseline[device_id] = _device_shallow_keys(entry, device_id)
                return True, detail
            last_err = f"HTTP {r.status_code}"
            if r.status_code in (401, 403):
                return False, "Firebase Permission Denied"
        except requests.exceptions.Timeout:
            last_err = "Timeout"
        except requests.exceptions.ConnectionError:
            last_err = "Connection failed"
        except Exception as e:
            last_err = str(e)[:80]
    return False, last_err


async def send_sms_async(entry: dict, device_id: str, to: str, msg: str,
                         baseline: Dict[str, Set[str]],
                         confirm_wait: float = 6.0) -> Tuple[bool, str]:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _send_sms_sync, entry, device_id, to, msg, baseline, confirm_wait)


def failure_summary(reasons: Set[str]) -> str:
    if not reasons:
        return ""
    top = sorted(reasons, key=lambda r: -sum(1 for x in reasons if x == r))[0]
    return f" (top: {top})"


# ===================== DAILY USAGE TRACKING =====================
def today_str() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def get_usage_map(firebase_url: str) -> Dict[str, int]:
    """Returns {device_id: count} for today. Applies globally across all bot users."""
    map_: Dict[str, int] = {}
    if not firebase_url:
        return map_
    try:
        conn = sqlite3.connect(DB_FILE, timeout=10)
        cur = conn.cursor()
        cur.execute(
            "SELECT device_id, count FROM sms_usage WHERE firebase_url = ? AND day = ?",
            (norm_device(firebase_url), today_str()),
        )
        for device_id, count in cur.fetchall():
            map_[device_id] = count
        conn.close()
    except Exception as e:
        logging.getLogger(__name__).error(f"usage load error: {e}")
    return map_


def norm_device(s: str) -> str:
    return s.rstrip("/")


def record_send(firebase_url: str, device_id: str):
    try:
        conn = sqlite3.connect(DB_FILE, timeout=10)
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO sms_usage (firebase_url, device_id, day, count, updated_at)
               VALUES (?, ?, ?, 1, CURRENT_TIMESTAMP)
               ON CONFLICT(firebase_url, device_id, day)
               DO UPDATE SET count = count + 1, updated_at = CURRENT_TIMESTAMP""",
            (norm_device(firebase_url), str(device_id), today_str()),
        )
        conn.commit()
        conn.close()
    except Exception as e:
        logging.getLogger(__name__).error(f"usage record error: {e}")


def get_selected_firebase_entries(user_cfg: dict) -> List[dict]:
    """Return firebase entries for ALL selected indexes (multi-select)."""
    lst = user_cfg.get("firebase_list", [])
    sel = user_cfg.get("selected_firebase_indexes") or []
    entries = [lst[i] for i in sorted(set(sel)) if 0 <= i < len(lst)]
    if entries:
        return entries
    a = user_cfg.get("active_firebase_index", 0)
    if 0 <= a < len(lst):
        return [lst[a]]
    return []


def device_key(fb_url: str, device_id: str) -> str:
    return f"{fb_url.rstrip('/')}::{device_id}"


def auto_select_last(user_cfg: dict):
    """Select the just-added (last) firebase in multi-select list."""
    lst = user_cfg.setdefault("firebase_list", [])
    idx = len(lst) - 1
    user_cfg["active_firebase_index"] = max(0, idx)
    if idx < 0:
        return
    sel = user_cfg.get("selected_firebase_indexes") or []
    if idx not in sel:
        sel.append(idx)
    user_cfg["selected_firebase_indexes"] = sorted(sel)


def auto_select_new(user_cfg: dict, old_len: int):
    """Select all firebases that were appended after old_len."""
    lst = user_cfg.get("firebase_list", [])
    sel = user_cfg.get("selected_firebase_indexes") or []
    for i in range(old_len, len(lst)):
        if i not in sel:
            sel.append(i)
    user_cfg["selected_firebase_indexes"] = sorted(sel)
    if lst:
        user_cfg["active_firebase_index"] = len(lst) - 1


def get_online_devices_all(entries: List[dict]) -> Dict[str, tuple]:
    """Aggregate online devices across multiple firebases.
    Returns {key: (entry, device_id, device_data)} so each send hits the correct
    project and we can read the SIM list / confirm results from the device node."""
    online: Dict[str, tuple] = {}
    for entry in entries:
        url = entry.get("url", "")
        devs = get_online_devices(entry)
        for did, data in devs.items():
            online[device_key(url, did)] = (entry, did, data)
    return online


def get_usage_map_multi(entries: List[dict]) -> Dict[str, int]:
    usage: Dict[str, int] = {}
    for entry in entries:
        url = entry.get("url", "")
        for did, c in get_usage_map(url).items():
            usage[device_key(url, did)] = c
    return usage


def pick_best_device(online: Dict[str, tuple], usage: Dict[str, int], limit: int,
                     excluded: Optional[Set[str]] = None) -> Tuple[Optional[str], Optional[dict], Optional[str], int]:
    """Pick the online (key, entry, device_id) with the lowest daily count (< limit).

    online: {key: (entry, device_id, device_data)} aggregated across all selected firebases.
    """
    excluded = excluded or set()
    best_key, best_entry, best_did, best_count = None, None, None, limit
    for key, (entry, did, _data) in online.items():
        if key in excluded:
            continue
        c = usage.get(key, 0)
        if c >= limit:
            continue
        if c < best_count:
            best_count, best_key, best_entry, best_did = c, key, entry, did
    return best_key, best_entry, best_did, best_count


def total_today_usage() -> Tuple[int, int]:
    try:
        conn = sqlite3.connect(DB_FILE, timeout=10)
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*), COALESCE(SUM(count), 0) FROM sms_usage WHERE day = ?", (today_str(),))
        rows, total = cur.fetchone()
        conn.close()
        return int(rows or 0), int(total or 0)
    except Exception:
        return 0, 0


# ===================== VEHICLE FILE PARSING =====================
HEADER_MAP = {
    "vehicle": "VEHICLE", "vehicle no": "VEHICLE", "vehicle no.": "VEHICLE",
    "vehicle number": "VEHICLE", "vehicleno": "VEHICLE", "veh no": "VEHICLE",
    "reg": "VEHICLE", "registration": "VEHICLE", "reg no": "VEHICLE",
    "registration no": "VEHICLE", "registration number": "VEHICLE", "regno": "VEHICLE",
    "registrationno": "VEHICLE", "vrn": "VEHICLE", "number plate": "VEHICLE",
    "plate no": "VEHICLE", "plateno": "VEHICLE", "vehicle no.": "VEHICLE",
    "vehicle_no": "VEHICLE", "vehicle number no": "VEHICLE",
    "mobile": "MOBILE", "mobile no": "MOBILE", "mobile no.": "MOBILE",
    "mobile number": "MOBILE", "mobileno": "MOBILE", "mob no": "MOBILE",
    "mob": "MOBILE", "phone": "MOBILE", "phone number": "MOBILE",
    "phonenumber": "MOBILE", "contact": "MOBILE", "contact no": "MOBILE",
    "contact number": "MOBILE", "contactnumber": "MOBILE", "owner number": "MOBILE",
    "owner no": "MOBILE", "number": "MOBILE", "msisdn": "MOBILE", "sim": "MOBILE",
    "mobile_no": "MOBILE", "mobile number": "MOBILE", "mob. no.": "MOBILE",
    "owner": "OWNER", "owner name": "OWNER", "name": "OWNER", "vehicle owner": "OWNER",
    "owner_name": "OWNER", "customer": "OWNER", "customer name": "OWNER",
    "address": "ADDRESS", "owner address": "ADDRESS", "address1": "ADDRESS",
    "owner_address": "ADDRESS", "full address": "ADDRESS", "address line": "ADDRESS",
    "model": "MODEL", "vehicle model": "MODEL", "make": "MODEL", "vehiclemodel": "MODEL",
    "vehicle name": "MODEL", "vehicle_model": "MODEL", "car model": "MODEL",
    "registration date": "REG_DATE", "reg date": "REG_DATE", "regdate": "REG_DATE",
    "reg.date": "REG_DATE", "reg date.": "REG_DATE", "reg. date": "REG_DATE",
    "vehicle registration date": "REG_DATE", "registrationdate": "REG_DATE",
    "date of registration": "REG_DATE", "reg_date": "REG_DATE", "rgn": "REG_DATE",
    "chassis": "CHASSIS", "chassis number": "CHASSIS", "chassis no": "CHASSIS",
    "chassisno": "CHASSIS", "chassis_number": "CHASSIS", "chassis no.": "CHASSIS",
    "vin": "CHASSIS", "vin number": "CHASSIS",
    "engine": "ENGINE", "engine number": "ENGINE", "engine no": "ENGINE",
    "engineno": "ENGINE", "engine_number": "ENGINE",
}

POSITION_FALLBACK = ["VEHICLE", "MOBILE", "OWNER", "CONTACT", "ADDRESS", "MODEL", "REG_DATE", "CHASSIS", "ENGINE"]


def _clean_cell(v) -> str:
    s = str(v or "").strip().strip('"').strip("'")
    return s


def _looks_like_header_row(row: List[str]) -> bool:
    if not row:
        return False
    cells = [_clean_cell(c).lower() for c in row]
    if len(cells) >= 2 and all(c in HEADER_MAP for c in cells[:2]):
        return True
    if cells and cells[0] in ("vehicle", "reg", "vehicle no", "vehicle number"):
        return True
    return False


def parse_vehicle_bytes(raw: bytes, filename: str = "") -> Tuple[bool, Optional[dict], str]:
    try:
        text = raw.decode("utf-8", errors="ignore").strip()
    except Exception:
        return False, None, "File read error."
    if not text:
        return False, None, "File khali hai."

    try:
        sniff = csv.Sniffer().sniff(text[:4096], delimiters=[",", ";", "\t", "|"])
        delimiter = sniff.delimiter
    except Exception:
        delimiter = ","
    if "\t" in text and delimiter not in (",", ";"):
        delimiter = "\t"

    reader = csv.reader(io.StringIO(text), delimiter=delimiter)
    all_rows = []
    for line in reader:
        stripped = [_clean_cell(c) for c in line]
        if not any(stripped):
            continue
        all_rows.append(stripped)

    if not all_rows:
        return False, None, "File me koi valid row nahi mili."

    header = _looks_like_header_row(all_rows[0])
    col_map: List[str] = []
    data_rows = all_rows
    if header:
        header_cells = all_rows[0]
        data_rows = all_rows[1:]
        for idx, cell in enumerate(header_cells):
            key = HEADER_MAP.get(cell.lower().strip())
            col_map.append(key if key else f"COL_{idx + 1}")
        deduped = []
        seen = set()
        for c in col_map:
            if c in seen:
                c = c + "_2"
            seen.add(c)
            deduped.append(c)
        col_map = deduped
    else:
        col_map = [POSITION_FALLBACK[i] if i < len(POSITION_FALLBACK) else f"COL_{i + 1}"
                   for i in range(len(all_rows[0]))]

    rows = []
    errors = 0
    for r_i, line in enumerate(data_rows):
        row: Dict[str, str] = {}
        for idx, cell in enumerate(line):
            key = col_map[idx] if idx < len(col_map) else f"COL_{idx + 1}"
            row[key] = cell
        if "VEHICLE" not in row and len(line) > 0:
            row["VEHICLE"] = line[0]
        if "MOBILE" not in row and len(line) > 1:
            row["MOBILE"] = line[1]
        vehicle = _clean_cell(row.get("VEHICLE"))
        mobile = _clean_cell(row.get("MOBILE"))
        if not vehicle or not mobile:
            errors += 1
            continue
        mobile_digits = re.sub(r"\D", "", mobile)
        if len(mobile_digits) < 4 or len(mobile_digits) > 15:
            errors += 1
            continue
        row["VEHICLE"] = vehicle.upper()
        row["MOBILE"] = "+" + mobile_digits if mobile_digits.startswith("91") and len(mobile_digits) == 12 else mobile_digits
        rows.append(row)
        if len(rows) >= MAX_FILE_ROWS:
            break

    if not rows:
        return False, None, "Koi valid 'Vehicle, Mobile' pair nahi mila. File check karein."

    return True, {
        "name": filename or "uploaded_file",
        "rows": rows,
        "total": len(rows),
        "errors": errors,
        "parsed_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "delimiter": delimiter,
        "has_header": header,
    }, f"{len(rows)} rows parsed ({errors} skipped)"


def fill_template(template: str, row: Dict[str, str], index: int) -> str:
    out = template or ""
    mapping = {"N": str(index), "SNO": str(index), "SL": str(index), "NO": str(index)}
    for k, v in row.items():
        mapping[str(k).upper()] = str(v)
    for k, v in mapping.items():
        out = out.replace("{" + k + "}", v)
    out = re.sub(r"\{\w+\}", "", out)
    return out.strip()


TEMPLATE_HELP_TEXT = (
    "✏️ <b>Template banate samay in placeholders ko use karein</b> (auto-replace honge):\n\n"
    "<code>{VEHICLE}</code> – Vehicle Number\n"
    "<code>{MOBILE}</code> – Mobile Number\n"
    "<code>{OWNER}</code> – Owner Name\n"
    "<code>{CONTACT}</code> – Owner Contact (Mobile)\n"
    "<code>{ADDRESS}</code> – Owner Address\n"
    "<code>{MODEL}</code> – Vehicle Model\n"
    "<code>{REG_DATE}</code> – Registration Date\n"
    "<code>{CHASSIS}</code> – Chassis Number\n"
    "<code>{ENGINE}</code> – Engine Number\n"
    "<code>{N}</code> – Serial Number\n\n"
    "⚠️ <i>Uploaded file me jitne columns honge unhi placeholders fill honge.\n"
    "Missing fields blank ho jayenge.</i>\n\n"
    f"📏 <b>Limit:</b> {MAX_TEMPLATE_CHARS} characters (spaces + newlines included)\n\n"
    "✅ <b>Example Template:</b>\n"
    "<code>Test {VEHICLE}\n\n"
    "Vehicle owner: {OWNER}\n"
    "Contact: {MOBILE}\n"
    "owner address: {ADDRESS}\n"
    "Vehicle model: {MODEL}\n"
    "Vehicle Registration date: {REG_DATE}\n"
    "Chassis Number: {CHASSIS}\n"
    "Engine Number: {ENGINE}\n\n"
    "Testing</code>\n\n"
    "Ab apna template text bhejein 👇"
)


# ===================== KEYBOARDS =====================
def get_main_keyboard(user_id: int):
    rows = [
        [KeyboardButton("📤 Upload Vehicle File"), KeyboardButton("📝 Message Templates")],
        [KeyboardButton("📁 Manage Firebase"), KeyboardButton("🚀 Send Bulk SMS")],
        [KeyboardButton("📊 Status"), KeyboardButton("📟 Daily Usage")],
    ]
    if is_admin(user_id):
        rows.append([KeyboardButton("👑 Admin Panel")])
    return ReplyKeyboardMarkup(rows, resize_keyboard=True)


def is_admin_admin() -> bool:
    return bool(ADMIN_IDS)


FIREBASE_SUB = ReplyKeyboardMarkup(
    [
        [KeyboardButton("🌐 Add Public Firebase"), KeyboardButton("🔒 Add Private Firebase")],
        [KeyboardButton("📋 Select Firebase"), KeyboardButton("🗑️ Delete Firebase")],
        [KeyboardButton("🔙 Back")],
    ],
    resize_keyboard=True,
)

TEMPLATE_SUB = ReplyKeyboardMarkup(
    [
        [KeyboardButton("➕ New Template"), KeyboardButton("📋 My Templates")],
        [KeyboardButton("🗑️ Delete Template")],
        [KeyboardButton("🔙 Back")],
    ],
    resize_keyboard=True,
)

ADMIN_SUB = ReplyKeyboardMarkup(
    [
        [KeyboardButton("👤 Approve User")],
        [KeyboardButton("🚫 Revoke Access"), KeyboardButton("👥 Users List")],
        [KeyboardButton("📈 Stats")],
        [KeyboardButton("🔙 Back")],
    ],
    resize_keyboard=True,
)


# ===================== STATUS / HELPERS =====================
def _fb_short(fb: dict) -> str:
    return (fb.get("url", "") or "").rstrip("/").split("//")[-1][:45]


def _fb_lock_tag(fb: dict) -> str:
    return "🔒 " if (fb.get("secret") or fb.get("service_account")) else "🌐 "


def build_firebase_select_kb(user_cfg: dict):
    lst = user_cfg.get("firebase_list", [])
    sel = set(user_cfg.get("selected_firebase_indexes") or [])
    kb = []
    for i, fb in enumerate(lst):
        mark = "☑️" if i in sel else "⬜"
        kb.append([InlineKeyboardButton(f"{mark} {_fb_lock_tag(fb)}{_fb_short(fb)}", callback_data=f"toggle_fb:{i}")])
    kb.append([
        InlineKeyboardButton("✅ Done", callback_data="fb_done"),
        InlineKeyboardButton("❌ Cancel", callback_data="fb_cancel"),
    ])
    return InlineKeyboardMarkup(kb)


def build_firebase_delete_kb(user_cfg: dict, marks: List[int]):
    lst = user_cfg.get("firebase_list", [])
    marks = set(marks)
    kb = []
    for i, fb in enumerate(lst):
        mark = "☑️" if i in marks else "⬜"
        kb.append([InlineKeyboardButton(f"{mark} {_fb_lock_tag(fb)}{_fb_short(fb)}", callback_data=f"del_toggle:{i}")])
    kb.append([InlineKeyboardButton(f"✅ Delete Selected ({len(marks)})", callback_data="del_selected")])
    kb.append([InlineKeyboardButton("🗑 Delete All", callback_data="del_all")])
    kb.append([InlineKeyboardButton("❌ Cancel", callback_data="fb_cancel")])
    return InlineKeyboardMarkup(kb)


def build_status_text(user_cfg: dict) -> str:
    fb_list = user_cfg.get("firebase_list", [])
    active = user_cfg.get("active_firebase_index", 0)
    active_fb = "None"
    fb_mode = ""
    if 0 <= active < len(fb_list):
        item = fb_list[active]
        url = item.get("url", "")
        if item.get("service_account"):
            fb_mode = " (🔒 Service Account)"
        elif item.get("secret"):
            fb_mode = " (🔒 Secret)"
        else:
            fb_mode = " (🌐 Public)"
        active_fb = f"{url}{fb_mode}"

    vf = user_cfg.get("vehicle_file")
    if vf:
        file_desc = f"`{html.escape(vf['name'])}` — {vf['total']} rows"
    else:
        file_desc = "Not uploaded"

    tpl = user_cfg.get("templates", [])
    tpl_idx = user_cfg.get("active_template_index", 0)
    tpl_name = tpl[tpl_idx]["name"] if 0 <= tpl_idx < len(tpl) else "Not selected"

    return (
        f"📊 <b>Bulk SMS Bot Status</b>\n\n"
        f"{subscription_status_text(user_cfg)}\n\n"
        f"🌐 <b>Active Firebase:</b> <code>{html.escape(active_fb)}</code> "
        f"<i>(Total: {len(fb_list)})</i>\n"
        f"📄 <b>Vehicle File:</b> {file_desc}\n"
        f"📝 <b>Template:</b> <code>{html.escape(tpl_name)}</code> <i>(Total: {len(tpl)})</i>\n"
        f"🔑 <b>Daily Limit:</b> {DAILY_LIMIT_PER_DEVICE} SMS per online gateway phone"
    )


def _tg_code(text: str, max_len: int = 48) -> str:
    """Safe <code> payload for Telegram HTML (no raw <>&, no newlines)."""
    s = str(text or "").replace("\x00", "").replace("\r", " ").replace("\n", " ").strip()
    if max_len and len(s) > max_len:
        s = s[:max_len]
    return "<code>" + html.escape(s, quote=False) + "</code>"


def _join_html_lines(lines: List[str], limit: int = 3800) -> str:
    """Join lines without slicing through an open HTML tag (Telegram 4096 cap)."""
    out: List[str] = []
    n = 0
    skipped = 0
    for line in lines:
        add = len(line) + 1
        if out and n + add > limit:
            skipped += 1
            continue
        out.append(line)
        n += add
    if skipped:
        out.append(f"… +{skipped} more")
    return "\n".join(out)


def build_usage_text(user_cfg: dict) -> str:
    entries = get_selected_firebase_entries(user_cfg)
    if not entries:
        return "❌ Pehle Firebase add/select karein."
    online = get_online_devices_all(entries)
    usage = get_usage_map_multi(entries)
    lines = [f"📟 <b>Daily Usage</b> — {len(entries)} selected Firebase, <b>{len(online)}</b> online phones\n"]
    for fb in entries:
        url = fb.get("url", "")
        prefix = url.rstrip("/") + "::"
        sub = [(k, packed) for k, packed in online.items() if k.startswith(prefix)]
        lines.append(f"\n🌐 {_tg_code(url.rstrip('/'), 60)} — {len(sub)} online")
        if not sub:
            lines.append("   🟠 no online phone")
            continue
        for k, packed in sub:
            # online values are (entry, device_id, device_data)
            if isinstance(packed, tuple) and len(packed) >= 3:
                entry, did, data = packed[0], packed[1], packed[2]
            elif isinstance(packed, tuple) and len(packed) >= 2:
                entry, did, data = packed[0], packed[1], {}
            else:
                continue
            cnt = usage.get(k, 0)
            left = max(0, DAILY_LIMIT_PER_DEVICE - cnt)
            try:
                if not isinstance(data, dict) or not data:
                    data = fetch_client_data(entry, did)
                model, phone, _ = device_display_meta(data if isinstance(data, dict) else {})
            except Exception:
                model, phone = "", ""
            label = model or phone or did
            lines.append(
                f"   🟢 {_tg_code(label, 38)} → <b>{cnt}/{DAILY_LIMIT_PER_DEVICE}</b> (left {left})"
            )
    return _join_html_lines(lines)


def fetch_client_data(entry: dict, did: str) -> dict:
    for path in (f"clients/{did}.json", f"devices/{did}.json"):
        url_stuff, headers = get_firebase_request_params(entry, path)
        data = fetch_json(url_stuff, headers=headers, timeout=6) if url_stuff else {}
        if data and isinstance(data, dict):
            return data
    return {}


# ===================== MENU BUTTON SET =====================
MENU_BUTTONS = {
    "📊 Status", "📤 Upload Vehicle File", "📝 Message Templates",
    "📁 Manage Firebase", "🚀 Send Bulk SMS", "📟 Daily Usage", "👑 Admin Panel",
    "🌐 Add Public Firebase", "🔒 Add Private Firebase", "📋 Select Firebase",
    "🗑️ Delete Firebase", "🔙 Back",
    "➕ New Template", "📋 My Templates", "🗑️ Delete Template",
    "📈 Stats", "👤 Approve User", "🚫 Revoke Access", "👥 Users List",
    "🔄 Check Status",
}


def looks_like_firebase_text(text: str) -> bool:
    t = (text or "").strip()
    if t.startswith("{") or "private_key" in t:
        return True
    if t.startswith(("https://", "http://")) and (
        "firebaseio" in t or "firebasedatabase" in t or "firebase" in t.lower().split("?")[0]
    ):
        return True
    return False


# ===================== CONVERSATION HANDLERS =====================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_access(update, context, check_sub=False):
        return ConversationHandler.END
    user_id = update.effective_user.id
    user_cfg = get_user_config(user_id)
    if not is_admin(user_id) and not get_subscription(user_cfg)["active"]:
        await update.message.reply_text(
            "🔐 <b>Bulk SMS Bot</b>\n\n"
            + subscription_status_text(user_cfg)
            + "\n\n<i>Approved hone ke baad /start dabao.</i>",
            parse_mode=ParseMode.HTML,
            reply_markup=get_sub_keyboard(),
        )
        return MAIN_MENU
    await update.message.reply_text(
        "🔥 <b>Bulk SMS Sender Bot</b>\n\n"
        "1️⃣ <b>📤 Upload Vehicle File</b> (.txt / .csv — Vehicle, Mobile)\n"
        "2️⃣ <b>📝 Message Template</b> kuch bhi — placeholders auto-fill honge\n"
        "3️⃣ <b>📁 Add Firebase</b> — online gateway phones filter honge\n"
        "4️⃣ <b>🚀 Send Bulk SMS</b> — har phone 100 SMS/day, phir next phone pe switch",
        parse_mode=ParseMode.HTML,
        reply_markup=get_main_keyboard(update.effective_user.id),
    )
    return MAIN_MENU


async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("pending_firebase_url", None)
    user_cfg = get_user_config(update.effective_user.id)
    await update.message.reply_text("Cancelled.", reply_markup=get_main_keyboard(update.effective_user.id))
    return MAIN_MENU


async def main_menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    user_id = update.effective_user.id

    # Subscription status peek — allowed even without an active subscription
    if text == "🔄 Check Status":
        user_cfg = get_user_config(user_id)
        await update.message.reply_text(
            subscription_status_text(user_cfg),
            parse_mode=ParseMode.HTML,
            reply_markup=get_main_keyboard(update.effective_user.id),
        )
        return MAIN_MENU

    if not await require_access(update, context):
        return MAIN_MENU
    user_cfg = get_user_config(user_id)

    # Quick-add Firebase: user pasted a URL / JSON straight into main menu
    if text and looks_like_firebase_text(text):
        return await add_private_or_public_firebase_auto(update, context, user_cfg, text)

    if text == "📊 Status":
        await update.message.reply_text(build_status_text(user_cfg), parse_mode=ParseMode.HTML,
                                        reply_markup=get_main_keyboard(update.effective_user.id))
        return MAIN_MENU

    if text == "📤 Upload Vehicle File":
        await update.message.reply_text(
            "📤 Send apni <b>.txt / .csv</b> file.\n\n"
            "📄 Format (2 columns):\n"
            "<code>Vehicle Number, Mobile Number</code>\n\n"
            "Example:\n"
            "<code>DL10AD1321,9821179707</code>\n"
            "<code>KL07BB2273,9778019655</code>\n\n"
            "Extra columns bhi chalenge (Owner, Address, Model…) — template unhe auto-map karega.",
            parse_mode=ParseMode.HTML,
            reply_markup=get_main_keyboard(update.effective_user.id),
        )
        return MAIN_MENU

    if text == "📝 Message Templates":
        await update.message.reply_text("📝 Template Management:", reply_markup=TEMPLATE_SUB)
        return MAIN_MENU

    if text == "📁 Manage Firebase":
        await update.message.reply_text("📁 Firebase Management:", reply_markup=FIREBASE_SUB)
        return MAIN_MENU

    if text == "🚀 Send Bulk SMS":
        return await start_send_flow(update, context, user_cfg)

    if text == "📟 Daily Usage":
        status = await update.message.reply_text("🔍 Fetching online devices…")
        try:
            usage_text = build_usage_text(user_cfg)
        except Exception as e:
            usage_text = f"❌ Error: {html.escape(str(e))}"
        try:
            await status.edit_text(usage_text, parse_mode=ParseMode.HTML)
        except Exception:
            plain = re.sub(r"<[^>]+>", "", usage_text or "")
            try:
                await status.edit_text((plain or "❌ Daily Usage failed.")[:4000])
            except Exception:
                await update.message.reply_text((plain or "❌ Daily Usage failed.")[:4000])
        return MAIN_MENU
    if text == "👑 Admin Panel":
        if is_admin(user_id):
            await update.message.reply_text("👑 Admin Panel:", reply_markup=ADMIN_SUB)
        return MAIN_MENU
    if text == "📈 Stats":
        if is_admin(user_id):
            await cmd_stats(update, context)
        return MAIN_MENU
    if text == "👤 Approve User":
        if is_admin(user_id):
            await update.message.reply_text(
                "👤 <b>Approve User</b>\n\nJis Telegram user ko subscription dena hai uski <b>numeric User ID</b> bhejo.\n\n"
                "User ID janne ke liye: unhe bot me <b>/start</b> dila kar ke tumhara <b>👥 Users List</b> dekho.\n\n"
                "<i>(Menu button dabane par cancel)</i>",
                parse_mode=ParseMode.HTML,
            )
            return AWAIT_APPROVE_ID
        return MAIN_MENU
    if text == "🚫 Revoke Access":
        if is_admin(user_id):
            await update.message.reply_text(
                "🚫 <b>Revoke Access</b>\n\nJis user ka subscription hataana hai uski <b>numeric User ID</b> bhejo.\n\n"
                "<i>(Menu button dabane par cancel)</i>",
                parse_mode=ParseMode.HTML,
            )
            return AWAIT_REVOKE_ID
        return MAIN_MENU
    if text == "👥 Users List":
        if is_admin(user_id):
            text_out, total, max_p = build_users_list(0)
            kb = []
            if max_p > 0:
                kb.append([InlineKeyboardButton("Next ➡️", callback_data="ausers:1")])
            kb.append([InlineKeyboardButton("🔙 Back", callback_data="fb_cancel")])
            await update.message.reply_text(text_out, parse_mode=ParseMode.HTML,
                                            reply_markup=InlineKeyboardMarkup(kb))
        return MAIN_MENU

    if text == "🌐 Add Public Firebase":
        await update.message.reply_text(
            "🌐 <b>Public Firebase URL(s) bhejein</b>\n\n"
            "Ek message me multiple URLs add kar sakte ho (har line par ek):\n"
            "<code>https://proj1-default-rtdb.firebaseio.com</code>\n"
            "<code>https://proj2-default-rtdb.firebaseio.com</code>\n\n"
            "URL me <code>?auth=SECRET</code> ho to wo private count hoga.\n"
            "<i>(Menu button dabane par cancel)</i>",
            parse_mode=ParseMode.HTML,
        )
        return AWAIT_PUBLIC_FIREBASE

    if text == "🔒 Add Private Firebase":
        await update.message.reply_text(
            "🔒 <b>Add Private Firebase</b>\n\n"
            "Koi bhi ek method:\n"
            "1️⃣ <b>URL:</b> <code>https://xyz.firebaseio.com</code> (phir Secret maangega)\n"
            "2️⃣ <b>URL with Secret:</b> <code>https://xyz.firebaseio.com?auth=SECRET</code>\n"
            "3️⃣ <b>Service Account .json</b> file upload karein\n\n"
            "<i>Multiple URLs ek message me bhi (har line ek).</i>\n"
            "<i>(Menu button dabane par cancel)</i>",
            parse_mode=ParseMode.HTML,
        )
        return AWAIT_PRIVATE_FIREBASE

    if text == "📋 Select Firebase":
        lst = user_cfg.get("firebase_list", [])
        if not lst:
            await update.message.reply_text("❌ No Firebase stored.", reply_markup=FIREBASE_SUB)
            return MAIN_MENU
        sel = user_cfg.get("selected_firebase_indexes") or []
        await update.message.reply_text(
            f"📋 <b>Select Firebase(s)</b> — <i>jittne select karoge, unke online phones combine ho jayenge</i> "
            f"(Total: {len(lst)}, Selected: {len(sel)})\n\n"
            "☑️ = selected (usi ke phones send me use honge)",
            parse_mode=ParseMode.HTML,
            reply_markup=build_firebase_select_kb(user_cfg),
        )
        return MAIN_MENU

    if text == "🗑️ Delete Firebase":
        lst = user_cfg.get("firebase_list", [])
        if not lst:
            await update.message.reply_text("❌ No Firebase stored.", reply_markup=FIREBASE_SUB)
            return MAIN_MENU
        context.user_data["fb_delete_marks"] = []
        await update.message.reply_text(
            f"🗑️ <b>Delete Firebase</b> — delete karne wale check karo ☑️ "
            f"(Total: {len(lst)})\n\n<i>Saare ek saath hatane ke liye <b>Delete All</b>.</i>",
            parse_mode=ParseMode.HTML,
            reply_markup=build_firebase_delete_kb(user_cfg, []),
        )
        return MAIN_MENU

    if text == "➕ New Template":
        await update.message.reply_text(
            "✏️ Template ka <b>naam</b> bhejein\n(e.g. <code>RC_SMS</code>):\n\n"
            f"📏 Message body limit: <b>{MAX_TEMPLATE_CHARS}</b> characters\n"
            "<i>(Menu button dabane par cancel)</i>",
            parse_mode=ParseMode.HTML,
        )
        return AWAIT_TEMPLATE_NAME

    if text == "📋 My Templates":
        tpl = user_cfg.get("templates", [])
        if not tpl:
            await update.message.reply_text("❌ Koi template nahi bana.", reply_markup=TEMPLATE_SUB)
            return MAIN_MENU
        kb = []
        for i, t in enumerate(tpl):
            mark = " ⭐" if i == user_cfg.get("active_template_index", 0) else ""
            kb.append([InlineKeyboardButton(f"📝 {t['name']}{mark}", callback_data=f"sel_tpl|{i}")])
        kb.append([InlineKeyboardButton("🔙 Cancel", callback_data="tpl_cancel")])
        await update.message.reply_text("Select template (preview + set active):", reply_markup=InlineKeyboardMarkup(kb))
        return MAIN_MENU

    if text == "🗑️ Delete Template":
        tpl = user_cfg.get("templates", [])
        if not tpl:
            await update.message.reply_text("❌ Koi template nahi bana.", reply_markup=TEMPLATE_SUB)
            return MAIN_MENU
        kb = [[InlineKeyboardButton(f"❌ {t['name']}", callback_data=f"del_tpl|{i}")] for i, t in enumerate(tpl)]
        kb.append([InlineKeyboardButton("🔙 Cancel", callback_data="tpl_cancel")])
        await update.message.reply_text("Select template to delete:", reply_markup=InlineKeyboardMarkup(kb))
        return MAIN_MENU

    if text == "🔙 Back":
        await update.message.reply_text("Main menu:", reply_markup=get_main_keyboard(update.effective_user.id))
        return MAIN_MENU

    if text in ("⏹️ Stop Sending", "/stop"):
        context.user_data["stop_bulk"] = True
        await update.message.reply_text("⏹️ Stop request sent.", reply_markup=get_main_keyboard(update.effective_user.id))
        return MAIN_MENU

    await update.message.reply_text("Use the buttons below.", reply_markup=get_main_keyboard(update.effective_user.id))
    return MAIN_MENU


async def add_private_or_public_firebase_auto(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                              user_cfg: dict, text: str) -> int:
    """Route pasted URL / JSON text to the right public/private handler."""
    await update.message.reply_text("⏳ Firebase check ho raha hai…")
    if text.startswith("{") or "private_key" in text:
        return await handle_private_json_text(update, context, user_cfg, text)
    if "?auth=" in text or "access_token=" in text:
        return await handle_private_urls(update, context, user_cfg, text)
    return await handle_public_firebase_text(update, context, user_cfg, text)


async def file_upload_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles .txt/.csv vehicle files AND .json service-account files, from any state."""
    if not await require_access(update, context):
        return MAIN_MENU
    user_id = update.effective_user.id
    user_cfg = get_user_config(user_id)
    doc = update.message.document
    if not doc:
        await update.message.reply_text("❌ Document nahi mila.")
        return MAIN_MENU

    name = (doc.file_name or "").lower()
    try:
        file = await context.bot.get_file(doc.file_id)
        raw = await file.download_as_bytearray()
    except Exception as e:
        await update.message.reply_text(f"❌ File download error: {html.escape(str(e))}")
        return MAIN_MENU

    if name.endswith(".json") or (not name.endswith((".txt", ".csv")) and raw[:1] == b"{"):
        return await handle_service_account_file(update, context, user_cfg, name, bytes(raw))

    if name.endswith(".txt") or name.endswith(".csv") or name.endswith(".tsv"):
        return await handle_vehicle_file_bytes(update, context, user_cfg, name, bytes(raw))

    await update.message.reply_text(
        "❌ Sirf <b>.txt</b>, <b>.csv</b> ya Service Account <b>.json</b> accept hote hain.",
        parse_mode=ParseMode.HTML,
        reply_markup=get_main_keyboard(update.effective_user.id),
    )
    return MAIN_MENU


async def handle_vehicle_file_bytes(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                    user_cfg: dict, name: str, raw: bytes) -> int:
    status = await update.message.reply_text("📥 File parse ho rahi hai…")
    ok, parsed, note = parse_vehicle_bytes(raw, name)
    if not ok:
        # edit_text only accepts InlineKeyboardMarkup — never ReplyKeyboardMarkup
        await status.edit_text(f"❌ {html.escape(note)}", parse_mode=ParseMode.HTML)
        await update.message.reply_text("👇 Menu", reply_markup=get_main_keyboard(update.effective_user.id))
        return MAIN_MENU
    user_cfg["vehicle_file"] = parsed
    save_user_config(update.effective_user.id, user_cfg)

    preview_parts = [f"✅ <b>Vehicle File Loaded!</b>\n\n📄 Name: <code>{html.escape(name)}</code>\n"
                     f"🚗 Rows: <b>{parsed['total']}</b> {('(' + str(parsed['errors']) + ' skipped)') if parsed['errors'] else ''}\n\n"
                     f"<b>Preview (first 3):</b>"]
    for row in parsed["rows"][:3]:
        preview_parts.append(f"• <code>{html.escape(row['VEHICLE'])}</code> → <code>{html.escape(row['MOBILE'])}</code>")
    preview_parts.append("\nAb <b>🚀 Send Bulk SMS</b> dabakar send karo.")
    await status.edit_text("\n".join(preview_parts), parse_mode=ParseMode.HTML)
    await update.message.reply_text("👇 Menu", reply_markup=get_main_keyboard(update.effective_user.id))
    return MAIN_MENU


async def handle_service_account_file(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                      user_cfg: dict, name: str, raw: bytes) -> int:
    try:
        data = json.loads(raw.decode("utf-8", errors="ignore"))
    except Exception:
        await update.message.reply_text("❌ Invalid JSON file.", reply_markup=get_main_keyboard(update.effective_user.id))
        return MAIN_MENU
    return await handle_private_json_text(update, context, user_cfg, data)


async def handle_private_json_text(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                   user_cfg: dict, data) -> int:
    if not isinstance(data, dict):
        await update.message.reply_text("❌ Valid JSON object nahi hai.", reply_markup=get_main_keyboard(update.effective_user.id))
        return MAIN_MENU
    is_valid, project_id, default_url, err = parse_service_account_dict(data)
    if not is_valid:
        await update.message.reply_text(err or "❌ Invalid Service Account JSON.",
                                        reply_markup=get_main_keyboard(update.effective_user.id))
        return MAIN_MENU
    entry = {
        "url": default_url,
        "secret": "",
        "service_account": data,
        "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    ok, reason = await asyncio.get_running_loop().run_in_executor(
        None, lambda: test_firebase_auth(default_url, service_account=data)
    )
    if not ok:
        await update.message.reply_text(f"❌ Connect failed: {html.escape(reason)}",
                                        parse_mode=ParseMode.HTML,
                                        reply_markup=get_main_keyboard(update.effective_user.id))
        return MAIN_MENU
    user_cfg.setdefault("firebase_list", []).append(entry)
    auto_select_last(user_cfg)
    save_user_config(update.effective_user.id, user_cfg)
    online = len(get_online_devices(entry))
    await update.message.reply_text(
        f"✅ <b>Private Firebase Added!</b>\n\n"
        f"👤 Project: <code>{html.escape(project_id or '')}</code>\n"
        f"🛡️ Mode: 🔒 Service Account\n"
        f"🟢 Online gateway phones: <b>{online}</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=get_main_keyboard(update.effective_user.id),
    )
    return MAIN_MENU


async def public_firebase_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_access(update, context):
        return MAIN_MENU
    text = (update.message.text or "").strip()
    if text in MENU_BUTTONS:
        return await main_menu_handler(update, context)
    user_cfg = get_user_config(update.effective_user.id)
    return await handle_public_firebase_text(update, context, user_cfg, text)


async def handle_public_firebase_text(update: Update, context: ContextTypes.DEFAULT_TYPE,
                                      user_cfg: dict, text: str) -> int:
    lines = [l for l in (text or "").splitlines() if l.strip()]
    added = 0
    failed = 0
    errs = []
    old_len = len(user_cfg.setdefault("firebase_list", []))
    for line in lines:
        if not validate_firebase_url(line):
            failed += 1
            errs.append(f"Invalid URL: {line[:60]}")
            continue
        url, _ = parse_firebase_input(line)
        entry = {"url": url, "secret": "", "service_account": None,
                 "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        user_cfg.setdefault("firebase_list", []).append(entry)
        added += 1
    if added:
        auto_select_new(user_cfg, old_len)
    save_user_config(update.effective_user.id, user_cfg)
    msg = f"✅ <b>{added} Public Firebase Added!</b>\n"
    if failed:
        msg += f"⚠️ {failed} invalid skip kiye\n" + "\n".join("• " + html.escape(e) for e in errs)
    msg += "\n\nAb device check karne ke liye <b>📟 Daily Usage</b> ya <b>🚀 Send</b> karo."
    await update.message.reply_text(msg, parse_mode=ParseMode.HTML,
                                    reply_markup=get_main_keyboard(update.effective_user.id))
    return MAIN_MENU


async def private_firebase_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_access(update, context):
        return MAIN_MENU
    msg = update.message
    user_cfg = get_user_config(update.effective_user.id)
    text = (msg.text or "").strip()
    if text in MENU_BUTTONS:
        context.user_data.pop("pending_firebase_url", None)
        return await main_menu_handler(update, context)

    json_data, json_err = await extract_json_from_message(update, context)
    if json_err and msg and msg.document:
        await msg.reply_text(f"❌ {json_err}\n\nValid Service Account <code>.json</code> bhejo.",
                             parse_mode=ParseMode.HTML)
        return AWAIT_PRIVATE_FIREBASE
    if isinstance(json_data, dict):
        return await handle_private_json_text(update, context, user_cfg, json_data)

    if not text:
        await msg.reply_text("❌ Firebase URL ya Service Account .json bhejo.")
        return AWAIT_PRIVATE_FIREBASE

    if not validate_firebase_url(text):
        await msg.reply_text("❌ Invalid input.\n\n• Valid URL (https://...)\n• Ya Service Account .json file")
        return AWAIT_PRIVATE_FIREBASE

    clean_url, secret = parse_firebase_input(text)
    secret = clean_database_secret(secret)
    if secret:
        return await handle_private_urls(update, context, user_cfg, text)

    lines = [l for l in (text or "").splitlines() if validate_firebase_url(l)]
    if len(lines) > 1:
        # multiple URLs without secrets → add all as pending for one batch secret
        context.user_data["pending_firebase_urls"] = [parse_firebase_input(l)[0] for l in lines]
        added = []
        old_len = len(user_cfg.setdefault("firebase_list", []))
        for l in lines:
            u, _ = parse_firebase_input(l)
            entry = {"url": u, "secret": "", "service_account": None,
                     "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
            user_cfg.setdefault("firebase_list", []).append(entry)
            added.append(u)
        if added:
            auto_select_new(user_cfg, old_len)
        save_user_config(update.effective_user.id, user_cfg)
        await update.message.reply_text(
            f"⚠️ <b>{len(added)} URLs</b> bina secret ke add ho gaye (🌐 Public mode).\n"
            "Private secret lagana ho to <b>🔒 Add Private Firebase</b> se ek URL+secret bhejo.",
            parse_mode=ParseMode.HTML,
            reply_markup=get_main_keyboard(update.effective_user.id),
        )
        return MAIN_MENU

    context.user_data["pending_firebase_url"] = clean_url
    await msg.reply_text(
        f"🔐 <b>Private Firebase — Database Secret</b>\n\n"
        f"🔗 URL: <code>{html.escape(clean_url)}</code>\n\n"
        f"Is project ka <b>Database Secret</b> bhejo ya Service Account <code>.json</code> upload karo.\n\n"
        f"📍 Console: Project Settings ➔ Service accounts ➔ Database secrets",
        parse_mode=ParseMode.HTML,
    )
    return AWAIT_FIREBASE_SECRET


async def handle_private_urls(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              user_cfg: dict, text: str) -> int:
    lines = [l for l in (text or "").splitlines() if validate_firebase_url(l)]
    if not lines:
        lines = [text]
    added = 0
    last_url = ""
    last_mode = "secret"
    old_len = len(user_cfg.setdefault("firebase_list", []))
    for line in lines:
        clean_url, secret = parse_firebase_input(line)
        secret = clean_database_secret(secret)
        entry = {"url": clean_url, "secret": secret, "service_account": None,
                 "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        if secret:
            ok, reason = await asyncio.get_running_loop().run_in_executor(
                None, lambda: test_firebase_auth(clean_url, secret=secret)
            )
            if not ok:
                await update.message.reply_text(
                    f"❌ <code>{html.escape(clean_url)}</code> connect failed: {html.escape(reason)}",
                    parse_mode=ParseMode.HTML,
                )
                continue
            user_cfg.setdefault("firebase_list", []).append(entry)
            added += 1
            last_url = clean_url
        else:
            entry["secret"] = ""
            user_cfg.setdefault("firebase_list", []).append(entry)
            added += 1
            last_url = clean_url
    if added:
        auto_select_new(user_cfg, old_len)
    save_user_config(update.effective_user.id, user_cfg)
    await update.message.reply_text(
        f"✅ <b>{added} Private Firebase Added!</b>\n\n"
        f"🔗 {html.escape(last_url[:80])}\n🛡️ Mode: 🔒 Private",
        parse_mode=ParseMode.HTML,
        reply_markup=get_main_keyboard(update.effective_user.id),
    )
    return MAIN_MENU


async def firebase_secret_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_access(update, context):
        return MAIN_MENU
    msg = update.message
    text = (msg.text or "").strip()
    if text in MENU_BUTTONS:
        context.user_data.pop("pending_firebase_url", None)
        return await main_menu_handler(update, context)
    user_cfg = get_user_config(update.effective_user.id)
    url = context.user_data.get("pending_firebase_url")
    if not url:
        await msg.reply_text("❌ Session expired — 🔒 Add Private Firebase se URL dubara bhejo.",
                             reply_markup=get_main_keyboard(update.effective_user.id))
        return MAIN_MENU

    json_data, json_err = await extract_json_from_message(update, context)
    if json_err and msg and msg.document:
        await msg.reply_text(f"❌ {json_err}\n\nValid <code>.json</code> ya Database Secret bhejo.",
                             parse_mode=ParseMode.HTML)
        return AWAIT_FIREBASE_SECRET
    if isinstance(json_data, dict):
        context.user_data.pop("pending_firebase_url", None)
        return await handle_private_json_text(update, context, user_cfg, json_data)

    secret = clean_database_secret(text)
    if not secret:
        await msg.reply_text("❌ Empty secret — Database Secret paste karo ya Service Account .json bhejo.")
        return AWAIT_FIREBASE_SECRET

    if secret.startswith(("http://", "https://")) or "auth=" in text:
        clean_u, sec2 = parse_firebase_input(text)
        if sec2:
            url = clean_u or url
            context.user_data["pending_firebase_url"] = url
            secret = sec2

    entry = {"url": url, "secret": secret, "service_account": None,
             "added_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    status = await msg.reply_text("🔐 Testing…")
    ok, reason = await asyncio.get_running_loop().run_in_executor(
        None, lambda: test_firebase_auth(url, secret=secret)
    )
    if not ok:
        await status.edit_text(f"❌ Connect failed\n<code>{html.escape(url)}</code>\n⚠️ {html.escape(reason)}",
                               parse_mode=ParseMode.HTML)
        context.user_data["pending_firebase_url"] = url
        return AWAIT_FIREBASE_SECRET

    user_cfg.setdefault("firebase_list", []).append(entry)
    auto_select_last(user_cfg)
    save_user_config(update.effective_user.id, user_cfg)
    context.user_data.pop("pending_firebase_url", None)
    await status.edit_text(f"✅ <b>Private Firebase Added!</b>\n\n🔗 <code>{html.escape(url[:80])}</code>\n🛡️ Mode: 🔒 Secret",
                           parse_mode=ParseMode.HTML)
    await msg.reply_text("👇 Menu", reply_markup=get_main_keyboard(update.effective_user.id))
    return MAIN_MENU


async def template_name_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_access(update, context):
        return MAIN_MENU
    text = (update.message.text or "").strip()
    if text in MENU_BUTTONS:
        return await main_menu_handler(update, context)
    if len(text) > 60:
        await update.message.reply_text("❌ Naam 60 chars se chota rakho.")
        return AWAIT_TEMPLATE_NAME
    context.user_data["new_template_name"] = text
    await update.message.reply_text(TEMPLATE_HELP_TEXT, parse_mode=ParseMode.HTML)
    return AWAIT_TEMPLATE_TEXT


async def template_text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_access(update, context):
        return MAIN_MENU
    text = (update.message.text or "").strip()
    if text in MENU_BUTTONS:
        context.user_data.pop("new_template_name", None)
        return await main_menu_handler(update, context)
    name = context.user_data.get("new_template_name") or f"T{len(get_user_config(update.effective_user.id).get('templates', [])) + 1}"
    if not text:
        await update.message.reply_text("❌ Empty template — dobara bhejo.")
        return AWAIT_TEMPLATE_TEXT
    if len(text) > MAX_TEMPLATE_CHARS:
        await update.message.reply_text(
            f"❌ Template <b>{len(text)}</b> characters ka hai.\n"
            f"Limit <b>{MAX_TEMPLATE_CHARS}</b> characters hai — thoda chhota karke bhejo.",
            parse_mode=ParseMode.HTML,
        )
        return AWAIT_TEMPLATE_TEXT
    user_cfg = get_user_config(update.effective_user.id)
    user_cfg.setdefault("templates", []).append({
        "name": name, "text": text, "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    })
    user_cfg["active_template_index"] = len(user_cfg["templates"]) - 1
    save_user_config(update.effective_user.id, user_cfg)
    context.user_data.pop("new_template_name", None)
    preview = fill_template(text, {"VEHICLE": "HR26EV0002", "MOBILE": "9910056151", "OWNER": "SUMIT TUTEJA",
                                   "CONTACT": "9910056151", "ADDRESS": "HOUSE NO-6/43, SHIVAJI NAGAR",
                                   "MODEL": "HYUNDAI CRETA", "REG_DATE": "17-Jun-2022",
                                   "CHASSIS": "MALPC811VNM331931", "ENGINE": "G4LDNG001696"}, 1)
    shown = preview if len(preview) <= TG_PREVIEW_CHARS else (preview[:TG_PREVIEW_CHARS] + "…")
    await update.message.reply_text(
        f"✅ <b>Template Saved!</b>\n\n"
        f"📝 Name: <code>{html.escape(name)}</code>\n"
        f"📏 Length: <b>{len(text)}</b>/{MAX_TEMPLATE_CHARS} characters\n\n"
        f"<b>Sample Preview:</b>\n<code>{html.escape(shown)}</code>\n\n"
        f"Ab <b>🚀 Send Bulk SMS</b> dabao ya file upload karo.",
        parse_mode=ParseMode.HTML,
        reply_markup=get_main_keyboard(update.effective_user.id),
    )
    return MAIN_MENU


# ===================== ADMIN: SUBSCRIPTION MANAGEMENT =====================
def build_users_list(page: int = 0, per: int = 20) -> Tuple[str, int, int]:
    with cache_lock:
        items = sorted(user_cache.items(), key=lambda kv: int(kv[0]) if kv[0].isdigit() else 0)
    total = len(items)
    max_p = max(0, (total - 1) // per)
    page = max(0, min(int(page), max_p))
    chunk = items[page * per:(page + 1) * per]
    lines = [f"👥 <b>Users</b> ({total}) — page {page + 1}/{max_p + 1}:\n"]
    for uid, cfg in chunk:
        uid_i = int(uid)
        if is_admin(uid_i):
            tag = "👑 OWNER"
        elif is_banned(uid_i):
            tag = "🚫"
        else:
            sub = get_subscription(cfg)
            if sub["active"]:
                tag = f"✅ {max(0, int(sub['days_left']))}d"
            else:
                tag = "❌ no-sub"
        lines.append(f"{tag}  <code>{uid}</code>")
    return "\n".join(lines), total, max_p


async def approve_user_id_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_access(update, context):
        return MAIN_MENU
    user_id = update.effective_user.id
    if not is_admin(user_id):
        return MAIN_MENU
    text = (update.message.text or "").strip()
    if text in MENU_BUTTONS:
        return await main_menu_handler(update, context)
    if not text.isdigit():
        await update.message.reply_text("❌ Numeric User ID bhejo. (Menu button se cancel karo)")
        return AWAIT_APPROVE_ID
    target = int(text)
    get_user_config(target)
    context.user_data["approve_uid"] = target
    kb = [[InlineKeyboardButton(label, callback_data=f"sub_plan:{key}")] for key, (_, label) in SUB_PLANS.items()]
    kb.append([InlineKeyboardButton("🔙 Cancel", callback_data="sub_plan:cancel")])
    await update.message.reply_text(
        f"👤 User <code>{target}</code> ke liye plan choose karo:",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(kb),
    )
    return MAIN_MENU


async def revoke_user_id_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_access(update, context):
        return MAIN_MENU
    user_id = update.effective_user.id
    if not is_admin(user_id):
        return MAIN_MENU
    text = (update.message.text or "").strip()
    if text in MENU_BUTTONS:
        return await main_menu_handler(update, context)
    if not text.isdigit():
        await update.message.reply_text("❌ Numeric User ID bhejo. (Menu button se cancel karo)")
        return AWAIT_REVOKE_ID
    target = int(text)
    cfg = get_user_config(target)
    revoke_subscription(cfg)
    save_user_config(target, cfg)
    await update.message.reply_text(
        f"🚫 User <code>{target}</code> ka access revoke kar diya.",
        parse_mode=ParseMode.HTML,
        reply_markup=get_main_keyboard(update.effective_user.id),
    )
    return MAIN_MENU


async def subscribe_plan_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_access(update, context):
        return
    q = update.callback_query
    await q.answer()
    admin_id = update.effective_user.id
    if not is_admin(admin_id):
        return
    if q.data == "sub_plan:cancel":
        await q.edit_message_text("Cancelled.")
        return
    key = q.data.split(":", 1)[1]
    if key not in SUB_PLANS:
        return
    days, label = SUB_PLANS[key]
    uid = context.user_data.get("approve_uid")
    if not uid:
        await q.edit_message_text("❌ Session lost — dobara '👤 Approve User' se shuru karo.")
        return
    cfg = get_user_config(uid)
    until = set_subscription(cfg, days, label, by=admin_id)
    save_user_config(uid, cfg)
    sub = get_subscription(cfg)
    await q.edit_message_text(
        f"✅ <b>Subscription Granted!</b>\n\n"
        f"👤 User: <code>{uid}</code>\n"
        f"📦 Plan: <b>{label}</b>\n"
        f"📅 Till: <code>{until.strftime('%d-%b-%Y')}</code>\n"
        f"⏳ Days left: <b>{max(0, int(sub['days_left']))}</b>",
        parse_mode=ParseMode.HTML,
    )


async def users_list_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_access(update, context):
        return
    q = update.callback_query
    await q.answer()
    if not is_admin(update.effective_user.id):
        return
    if not q.data.startswith("ausers:"):
        return
    page = int(q.data.split(":", 1)[1] or 0)
    text_out, total, max_p = build_users_list(page)
    kb = []
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"ausers:{page - 1}"))
    if page < max_p:
        nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"ausers:{page + 1}"))
    if nav:
        kb.append(nav)
    kb.append([InlineKeyboardButton("🔙 Back", callback_data="fb_cancel")])
    try:
        await q.edit_message_text(text_out, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(kb))
    except Exception:
        await q.message.reply_text(text_out, parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup(kb))


async def cmd_grant(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if len(context.args) < 2 or not context.args[0].lstrip("-").isdigit() or not context.args[1].isdigit():
        await update.message.reply_text("Usage: /grant <user_id> <days>\ne.g. /grant 123456789 7")
        return
    uid = int(context.args[0])
    days = max(1, min(int(context.args[1]), 3650))
    cfg = get_user_config(uid)
    until = set_subscription(cfg, days, f"{days} Day(s)", by=update.effective_user.id)
    save_user_config(uid, cfg)
    await update.message.reply_text(
        f"✅ Granted <code>{uid}</code> → <b>{days} days</b> (till {until.strftime('%d-%b-%Y')})",
        parse_mode=ParseMode.HTML,
    )


async def cmd_revoke(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if not context.args or not context.args[0].lstrip("-").isdigit():
        await update.message.reply_text("Usage: /revoke <user_id>")
        return
    uid = int(context.args[0])
    cfg = get_user_config(uid)
    revoke_subscription(cfg)
    save_user_config(uid, cfg)
    await update.message.reply_text(f"🚫 Revoked <code>{uid}</code>", parse_mode=ParseMode.HTML)


# ===================== SEND FLOW =====================
async def start_send_flow(update: Update, context: ContextTypes.DEFAULT_TYPE, user_cfg: dict) -> int:
    vf = user_cfg.get("vehicle_file")
    if not vf or not vf.get("rows"):
        await update.message.reply_text(
            "❌ Pehle <b>📤 Upload Vehicle File</b> karo.",
            parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard(update.effective_user.id),
        )
        return MAIN_MENU

    tpl = user_cfg.get("templates", [])
    tpl_idx = user_cfg.get("active_template_index", 0)
    if not tpl:
        await update.message.reply_text(
            "❌ Pehle <b>➕ New Template</b> banao.",
            parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard(update.effective_user.id),
        )
        return MAIN_MENU
    template_text = tpl[min(tpl_idx, len(tpl) - 1)]["text"]

    entries = get_selected_firebase_entries(user_cfg)
    if not entries:
        await update.message.reply_text(
            "❌ Pehle <b>🌐 Add Public Firebase</b> ya <b>🔒 Add Private Firebase</b> karo.",
            parse_mode=ParseMode.HTML, reply_markup=get_main_keyboard(update.effective_user.id),
        )
        return MAIN_MENU

    status = await update.message.reply_text("🔍 Online gateway phones dhoond rahe hain…")
    online = get_online_devices_all(entries)
    if not online:
        await status.edit_text(
            "🟠 <b>Koi online gateway phone nahi mila</b> in selected Firebase(s).\n\n"
            "URL/secret check karo, apps phone pe online rakho, phir try karo.",
            parse_mode=ParseMode.HTML,
        )
        await update.message.reply_text("👇 Menu", reply_markup=get_main_keyboard(update.effective_user.id))
        return MAIN_MENU

    usage = get_usage_map_multi(entries)
    usable = {key: usage.get(key, 0) for key in online}
    total_usable_capacity = sum(max(0, DAILY_LIMIT_PER_DEVICE - c) for c in usable.values())
    total_rows = len(vf["rows"])

    tpl_name = tpl[min(tpl_idx, len(tpl) - 1)]["name"]
    sample = fill_template(template_text, vf["rows"][0], 1)

    kb = [
        [InlineKeyboardButton("✅ START SENDING", callback_data="bsms:start")],
        [InlineKeyboardButton("❌ Cancel", callback_data="bsms:cancel")],
    ]
    await status.edit_text(
        f"🚀 <b>Send Bulk SMS — Confirm</b>\n\n"
        f"📄 File: <code>{html.escape(vf['name'])}</code>\n"
        f"🚗 Rows: <b>{total_rows}</b>\n"
        f"📝 Template: <code>{html.escape(tpl_name)}</code>\n"
        f"🔥 Firebases: <b>{len(entries)}</b>\n\n"
        f"🟢 Online phones (combined): <b>{len(online)}</b>\n"
        f"📶 SIMs detected: <b>{sum(len(extract_sims(data)) for _k, (_e, _d, data) in online.items())}</b>\n"
        f"📦 Total capacity (100/phone/day): <b>{total_usable_capacity}</b>\n\n"
        f"🔎 <i>Har send ke baad phone se confirmation <b>read back</b> karenge — "
        f"<b>Sent by phone</b> vs <b>Queued only</b> alag-alag count hoga.</i>\n\n"
        f"<b>Sample (row 1):</b>\n<code>{html.escape(sample if len(sample) <= TG_PREVIEW_CHARS else sample[:TG_PREVIEW_CHARS] + '…')}</code>\n\n"
        f"<i>Start karne ke baad message ke neeche <b>STOP</b> button dikhega — dabate hi send ruk jayega. "
        f"Har online phone 100 SMS/day ke baad automatically next online phone pe switch hoga.</i>",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(kb),
    )
    context.user_data["send_confirmed"] = False
    return MAIN_MENU


async def cmd_stop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_access(update, context):
        return
    if context.user_data.get("bulk_running"):
        context.user_data["stop_bulk"] = True
        await update.message.reply_text("⏹️ Stop request bhej diya — agle SMS ke baad ruk jayega…")
    else:
        await update.message.reply_text("ℹ️ Abhi koi bulk send nahi chal raha.")


async def bulk_send_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_access(update, context):
        return
    q = update.callback_query
    await q.answer()
    if q.data == "bsms:cancel":
        await q.edit_message_text("Cancelled.")
        return
    if q.data == "bsms:stop":
        if context.user_data.get("bulk_running"):
            context.user_data["stop_bulk"] = True
            try:
                await q.edit_message_text("⏹️ Stop request bhej diya — ruk raha hai…")
            except Exception:
                pass
        return
    if q.data != "bsms:start":
        return
    if context.user_data.get("bulk_running"):
        await q.edit_message_text("⏳ Pehle se ek send chal raha hai. /stop se roko.")
        return
    user_cfg = get_user_config(update.effective_user.id)
    context.user_data["bulk_running"] = True
    context.user_data["stop_bulk"] = False
    asyncio.create_task(run_bulk_send_job(update, context, user_cfg, q))

async def run_bulk_send_job(update: Update, context: ContextTypes.DEFAULT_TYPE, user_cfg: dict, q):
    try:
        vf = user_cfg.get("vehicle_file")
        entries = get_selected_firebase_entries(user_cfg)
        if not vf or not entries:
            await q.edit_message_text("❌ Missing file/Firebase.")
            return
        rows = vf["rows"]
        tpl_idx = min(user_cfg.get("active_template_index", 0), len(user_cfg.get("templates", [])) - 1)
        template_text = user_cfg.get("templates", [])[tpl_idx]["text"]

        online = get_online_devices_all(entries)
        if not online:
            await q.edit_message_text("🟠 Koi online phone nahi mila.")
            return
        usage = get_usage_map_multi(entries)
        chat_id = update.effective_chat.id
        stop_kb = InlineKeyboardMarkup([[InlineKeyboardButton("⏹️ STOP SENDING", callback_data="bsms:stop")]])
        progress_msg = await q.edit_message_text(f"📤 Sending 0/{len(rows)}…")
        failure_reasons: Set[str] = set()
        ok = fail = skipped = stopped = 0
        confirmed = queued = 0
        sims_used: Set[str] = set()
        failed_devices: Set[str] = set()
        stop_flag = lambda: context.user_data.get("stop_bulk")

        total = len(rows)
        baseline: Dict[str, Set[str]] = {}
        last_update = 0
        for i, row in enumerate(rows, 1):
            if stop_flag():
                stopped = 1
                break
            number = re.sub(r"\D", "", row.get("MOBILE", "") or "")
            if not number:
                skipped += 1
                continue
            message = fill_template(template_text, row, i)
            key, entry, did, _ = pick_best_device(online, usage, DAILY_LIMIT_PER_DEVICE, excluded=failed_devices)
            if not did:
                break  # all phones hit daily limit (or all failed)

            try:
                confirm_wait = float(_load_settings_file().get("sendConfirmWaitS", 6.0))
            except Exception:
                confirm_wait = 6.0
            success, reason = await send_sms_async(entry, did, number, message, baseline, confirm_wait)
            if success:
                usage[key] = usage.get(key, 0) + 1
                record_send(entry.get("url", ""), did)
                ok += 1
                if "phone-confirmed" in reason:
                    confirmed += 1
                    m = re.search(r"SIM \d+", reason)
                    if m:
                        sims_used.add(m.group(0))
                else:
                    queued += 1
            else:
                fail += 1
                failure_reasons.add(reason or "?")
                if reason in ("Firebase Permission Denied", "Connection failed", "Timeout", "HTTP 404", "HTTP 400"):
                    failed_devices.add(key)
                await asyncio.sleep(0.4)

            if i % 3 == 0 or i == total:
                if time.time() - last_update > 1.5:
                    last_update = time.time()
                    try:
                        await progress_msg.edit_text(
                            f"📤 <b>Sending…</b> {i}/{total}\n\n"
                            f"❇️ Sent: <b>{ok}</b> (📲 phone-confirmed: <b>{confirmed}</b>, 🔎 queued: <b>{queued}</b>)\n"
                            f"⚠️ Failed: <b>{fail}</b>\n⏭️ Skipped: <b>{skipped}</b>\n\n"
                            f"<i>Rokne ke liye neeche STOP dabao ya /stop</i>",
                            parse_mode=ParseMode.HTML,
                            reply_markup=stop_kb,
                        )
                    except Exception:
                        pass
            await asyncio.sleep(SEND_DELAY)

        context.user_data["bulk_running"] = False
        context.user_data["stop_bulk"] = False

        extra = ""
        if stopped:
            extra = "\n⏹️ Stopped by user."
        if ok < total and fail == 0 and skipped == 0 and not stopped:
            extra += "\n⚠️ Daily limit (100/phone) reach — agle din phir try karo ya aur phones add karo."
        if failed_devices:
            extra += f"\n🔴 Failed devices: {len(failed_devices)} (temporarily skipped)"
        if ok and confirmed == 0 and fail == 0:
            extra += "\n⚠️ Koi bhi send phone se CONFIRM nahi hua (sirf Firebase queue me gaya) —\n"
            extra += "   • Phones online check karo (laptop/charger connected)\n"
            extra += "   • Android sendSms/listening permission on hai\n"
            extra += "   • SIM me balance/recharge hai (galat SIM pe SMS silent fail hota hai)"
        if sims_used:
            def _sim_sort_key(label: str) -> int:
                digits = re.sub(r"\D", "", str(label))
                return int(digits) if digits else 0
            sim_list = ", ".join(sorted(sims_used, key=_sim_sort_key))
            extra += f"\n📶 Confirmed SIM(s) used: {sim_list}"

        try:
            await progress_msg.edit_text(
                f"✅ <b>Bulk Send Finished!</b>{extra}\n\n"
                f"🚗 Total rows: <b>{total}</b>\n"
                f"❇️ Sent: <b>{ok}</b> — 📲 phone-confirmed: <b>{confirmed}</b>, 🔎 queued only: <b>{queued}</b>\n"
                f"⚠️ Failed: <b>{fail}</b>{failure_summary(failure_reasons)}\n"
                f"⏭️ Skipped: <b>{skipped}</b>\n\n"
                f"🟢 Online phones used: <b>{len(online)}</b>",
                parse_mode=ParseMode.HTML,
            )
        except Exception:
            await context.bot.send_message(chat_id, "✅ Bulk send done.")
        user_cfg["last_send_summary"] = {"ok": ok, "fail": fail, "skipped": skipped, "total": total,
                                         "confirmed": confirmed, "queued": queued,
                                         "at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        save_user_config(update.effective_user.id, user_cfg)
    except Exception as e:
        context.user_data["bulk_running"] = False
        logging.getLogger(__name__).exception("bulk send error")
        try:
            await q.edit_message_text(f"❌ Error: {html.escape(str(e))}")
        except Exception:
            pass


# ===================== FIREBASE / TEMPLATE CALLBACKS =====================
async def manage_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await require_access(update, context):
        return
    q = update.callback_query
    await q.answer()
    user_id = update.effective_user.id
    user_cfg = get_user_config(user_id)

    if q.data == "fb_cancel" or q.data == "tpl_cancel":
        await q.edit_message_text("Cancelled.")
        return

    if q.data == "fb_done":
        sel = user_cfg.get("selected_firebase_indexes") or []
        online = get_online_devices_all(get_selected_firebase_entries(user_cfg))
        await q.edit_message_text(
            f"✅ <b>Firebase selection saved</b> — <b>{len(sel)}</b> selected\n"
            f"🟢 Online phones (combined): <b>{len(online)}</b>\n"
            f"📶 SIMs detected: <b>{sum(len(extract_sims(data)) for _k, (_e, _d, data) in online.items())}</b>\n"
            f"📦 Daily capacity: <b>{len(online) * DAILY_LIMIT_PER_DEVICE}</b>",
            parse_mode=ParseMode.HTML,
        )
        return

    if q.data.startswith("toggle_fb:"):
        idx = int(q.data.split(":")[1])
        lst = user_cfg.get("firebase_list", [])
        if 0 <= idx < len(lst):
            sel = user_cfg.get("selected_firebase_indexes") or []
            if idx in sel:
                sel.remove(idx)
            else:
                sel.append(idx)
                user_cfg["active_firebase_index"] = idx
            user_cfg["selected_firebase_indexes"] = sorted(sel)
            save_user_config(user_id, user_cfg)
        try:
            await q.edit_message_text(
                f"📋 <b>Select Firebase(s)</b> (Total: {len(lst)}, Selected: {len(user_cfg['selected_firebase_indexes'])})\n\n"
                "☑️ = selected — online phones combine honge",
                parse_mode=ParseMode.HTML,
                reply_markup=build_firebase_select_kb(user_cfg),
            )
        except Exception:
            pass
        return

    marks: List[int] = context.user_data.get("fb_delete_marks") or []

    if q.data.startswith("del_toggle:"):
        idx = int(q.data.split(":")[1])
        lst = user_cfg.get("firebase_list", [])
        if 0 <= idx < len(lst):
            if idx in marks:
                marks.remove(idx)
            else:
                marks.append(idx)
            context.user_data["fb_delete_marks"] = marks
        try:
            await q.edit_message_text(
                f"🗑️ <b>Delete Firebase</b> — delete karne wale check karo ☑️ "
                f"(Total: {len(lst)}, Marked: {len(marks)})\n\n"
                f"<i>Saare ek saath hatane ke liye <b>Delete All</b>.</i>",
                parse_mode=ParseMode.HTML,
                reply_markup=build_firebase_delete_kb(user_cfg, marks),
            )
        except Exception:
            pass
        return

    if q.data in ("del_selected", "del_all"):
        lst = user_cfg.get("firebase_list", [])
        if q.data == "del_selected":
            if not marks:
                await q.answer("Pehle koi Firebase check karo ☑️", show_alert=True)
                return
            count = len(marks)
            kb = [
                [InlineKeyboardButton("✅ Yes, Delete", callback_data="confirm_del_marked")],
                [InlineKeyboardButton("❌ Cancel", callback_data="fb_cancel")],
            ]
        else:
            if not lst:
                await q.answer("Koi Firebase hai hi nahi.", show_alert=True)
                return
            count = len(lst)
            kb = [
                [InlineKeyboardButton("✅ Yes, Delete All", callback_data="confirm_del_all")],
                [InlineKeyboardButton("❌ Cancel", callback_data="fb_cancel")],
            ]
        await q.edit_message_text(
            f"⚠️ <b>{count}</b> Firebase(s) permanently delete kare? Ye action undo nahi ho sakta.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup(kb),
        )
        return

    if q.data == "confirm_del_marked":
        lst = user_cfg.get("firebase_list", [])
        if not marks:
            await q.edit_message_text("Kuch delete nahi hua (koi mark nahi tha).")
            return
        to_del = sorted(set(m for m in marks if 0 <= m < len(lst)), reverse=True)
        removed = set(to_del)
        for idx in to_del:
            lst.pop(idx)
        user_cfg["firebase_list"] = lst

        def _remap(old):
            if old in removed:
                return None
            return old - sum(1 for r in removed if r < old)

        sel = user_cfg.get("selected_firebase_indexes") or []
        new_sel = []
        for s in sel:
            ns = _remap(s)
            if ns is not None:
                new_sel.append(ns)
        user_cfg["selected_firebase_indexes"] = sorted(set(new_sel))

        active = user_cfg.get("active_firebase_index", 0)
        if not lst:
            user_cfg["active_firebase_index"] = 0
        else:
            na = _remap(active)
            user_cfg["active_firebase_index"] = na if (na is not None and na < len(lst)) else 0
        save_user_config(user_id, user_cfg)
        context.user_data["fb_delete_marks"] = []
        await q.edit_message_text(f"🗑️ <b>{len(to_del)}</b> Firebase(s) deleted. Ab total: {len(lst)}")
        return

    if q.data == "confirm_del_all":
        user_cfg["firebase_list"] = []
        user_cfg["active_firebase_index"] = 0
        user_cfg["selected_firebase_indexes"] = []
        save_user_config(user_id, user_cfg)
        context.user_data["fb_delete_marks"] = []
        await q.edit_message_text("🗑️ <b>Saare Firebase delete kar diye.</b>")
        return

    if q.data.startswith("sel_tpl|"):
        idx = int(q.data.split("|")[1])
        tpl = user_cfg.get("templates", [])
        if 0 <= idx < len(tpl):
            user_cfg["active_template_index"] = idx
            save_user_config(user_id, user_cfg)
            body = tpl[idx].get("text") or ""
            shown = body if len(body) <= TG_PREVIEW_CHARS else (body[:TG_PREVIEW_CHARS] + "…")
            await q.edit_message_text(
                f"✅ <b>Template active:</b> <code>{html.escape(tpl[idx]['name'])}</code>\n"
                f"📏 Length: <b>{len(body)}</b>/{MAX_TEMPLATE_CHARS} characters\n\n"
                f"<code>{html.escape(shown)}</code>",
                parse_mode=ParseMode.HTML,
            )
        return

    if q.data.startswith("del_tpl|"):
        idx = int(q.data.split("|")[1])
        tpl = user_cfg.get("templates", [])
        if 0 <= idx < len(tpl):
            name = tpl[idx]["name"]
            tpl.pop(idx)
            active = user_cfg.get("active_template_index", 0)
            if idx <= active:
                user_cfg["active_template_index"] = max(0, active - 1) if tpl else 0
            save_user_config(user_id, user_cfg)
            await q.edit_message_text(f"🗑️ Template '{name}' deleted.")
        return


# ===================== ADMIN COMMANDS =====================
async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    users = len(user_cache)
    fb_total = sum(len(c.get("firebase_list", [])) for c in user_cache.values())
    tpl_total = sum(len(c.get("templates", [])) for c in user_cache.values())
    files_total = sum(1 for c in user_cache.values() if c.get("vehicle_file"))
    subs_active = sum(1 for c in user_cache.values() if get_subscription(c)["active"])
    usage_rows, usage_total = total_today_usage()
    text = (
        f"📈 <b>Stats</b>\n\n"
        f"👥 Users: <b>{users}</b>\n"
        f"✅ Active subscribers: <b>{subs_active}</b>\n"
        f"🌐 Firebases: <b>{fb_total}</b>\n"
        f"📝 Templates: <b>{tpl_total}</b>\n"
        f"📄 Files uploaded: <b>{files_total}</b>\n"
        f"🚫 Banned: <b>{len(banned_set)}</b>\n\n"
        f"📟 Today total SMS: <b>{usage_total}</b> across {usage_rows} devices"
    )
    await update.message.reply_text(text, parse_mode=ParseMode.HTML, reply_markup=ADMIN_SUB)


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "📖 <b>Bulk SMS Bot — Help</b>\n\n"
        "<b>User Commands:</b>\n"
        "/start – Main menu\n"
        "/help – Ye help\n"
        "/stop – Chal raha send roko\n"
        "/cancel – Current action cancel\n\n"
        "<b>Features (main menu buttons):</b>\n"
        "• <b>📤 Upload Vehicle File</b> — .txt/.csv (Vehicle, Mobile)\n"
        "• <b>📝 Message Templates</b> — banao, save karo, select karo\n"
        "• <b>📁 Manage Firebase</b> — Public / Private / Service Account\n"
        "• <b>📋 Select Firebase</b> — ek se zyada select karo, online phones combine\n"
        "• <b>🚀 Send Bulk SMS</b> — har phone 100 SMS/day, next phone auto\n"
        "• <b>📟 Daily Usage</b> — aaj kitni SMS bheji\n\n"
    )
    if is_admin(update.effective_user.id):
        text += (
            "<b>Owner Commands:</b>\n"
            "/grant &lt;id&gt; &lt;days&gt; – Subscription do\n"
            "/revoke &lt;id&gt; – Access hatao\n"
            "/stats – Statistics\n"
            "/broadcast &lt;msg&gt; – Sab users ko message\n"
            "/userinfo &lt;id&gt; – User details\n"
            "/ban &lt;id&gt; / /unban &lt;id&gt; / /banned\n\n"
            f"👤 Owner: {OWNER_NAME} ({OWNER_USERNAME})\n"
        )
    text += "💳 Plans: 1 Day · 3 Days · 1 Week · 1 Month · 3 Months"
    await update.message.reply_text(text, parse_mode=ParseMode.HTML)


async def cmd_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if not context.args:
        await update.message.reply_text("Usage: /broadcast message")
        return
    message = " ".join(context.args)
    with cache_lock:
        uids = list(user_cache.keys())
    ok = fail = 0
    for uid in uids:
        try:
            await context.bot.send_message(int(uid), message)
            ok += 1
        except Exception:
            fail += 1
        await asyncio.sleep(0.03)
    await update.message.reply_text(f"✅ Done\nSuccess: {ok}\nFailed: {fail}")


async def cmd_userinfo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if not context.args:
        return
    try:
        tid = int(context.args[0])
    except ValueError:
        return
    cfg = get_user_config(tid)
    await update.message.reply_text(
        f"👤 <code>{tid}</code>\n"
        f"Firebases: <b>{len(cfg.get('firebase_list', []))}</b>\n"
        f"Templates: <b>{len(cfg.get('templates', []))}</b>\n"
        f"File rows: <b>{(cfg.get('vehicle_file') or {}).get('total', 0)}</b>\n"
        f"Banned: <b>{is_banned(tid)}</b>",
        parse_mode=ParseMode.HTML,
    )


async def cmd_ban(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if not context.args:
        return
    try:
        tid = int(context.args[0])
        if is_admin(tid):
            return
        ban_user(tid)
        await update.message.reply_text(f"🚫 Banned <code>{tid}</code>", parse_mode=ParseMode.HTML)
    except Exception:
        pass


async def cmd_unban(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    if not context.args:
        return
    unban_user(int(context.args[0]))
    await update.message.reply_text(f"✅ Unbanned <code>{context.args[0]}</code>", parse_mode=ParseMode.HTML)


async def cmd_banned(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    banned = get_banned_users()
    if not banned:
        await update.message.reply_text("No banned users")
        return
    await update.message.reply_text("🚫 Banned:\n" + "\n".join(f"<code>{u}</code>" for u in banned),
                                    parse_mode=ParseMode.HTML)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logging.getLogger(__name__).error(f"Error: {context.error}", exc_info=context.error)


# ===================== MAIN =====================
async def main():
    reload_runtime_config()
    init_db()
    load_cache()
    logging.basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=logging.INFO,
        handlers=[logging.FileHandler("smssenderbot.log"), logging.StreamHandler()],
    )
    logger = logging.getLogger(__name__)
    logger.info(f"⚙️ Runtime config | token={'yes' if BOT_TOKEN else 'NO'} | admins={ADMIN_IDS} | channel={CHANNEL_USERNAME or 'off'}")

    if not BOT_TOKEN:
        logger.critical("BOT_TOKEN required — settings.json me token daalo (telegramAutoBotToken/telegramBotToken)")
        sys.exit(1)

    app = Application.builder().token(BOT_TOKEN).build()

    conv = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            MAIN_MENU: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, main_menu_handler),
                MessageHandler(filters.Document.ALL & ~filters.COMMAND, file_upload_handler),
                CommandHandler("start", start),
                CommandHandler("cancel", cancel),
            ],
            AWAIT_PUBLIC_FIREBASE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, public_firebase_handler),
                MessageHandler(filters.Document.ALL & ~filters.COMMAND, file_upload_handler),
                CommandHandler("start", start),
            ],
            AWAIT_PRIVATE_FIREBASE: [
                MessageHandler((filters.TEXT | filters.Document.ALL) & ~filters.COMMAND, private_firebase_handler),
                CommandHandler("start", start),
            ],
            AWAIT_FIREBASE_SECRET: [
                MessageHandler((filters.TEXT | filters.Document.ALL) & ~filters.COMMAND, firebase_secret_handler),
                CommandHandler("start", start),
            ],
            AWAIT_TEMPLATE_NAME: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, template_name_handler),
                CommandHandler("start", start),
            ],
            AWAIT_TEMPLATE_TEXT: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, template_text_handler),
                CommandHandler("start", start),
            ],
            AWAIT_APPROVE_ID: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, approve_user_id_handler),
                CommandHandler("start", start),
            ],
            AWAIT_REVOKE_ID: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, revoke_user_id_handler),
                CommandHandler("start", start),
            ],
        },
        fallbacks=[
            CommandHandler("cancel", cancel),
            CommandHandler("start", start),
        ],
        allow_reentry=True,
    )
    app.add_handler(conv)

    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(CommandHandler("broadcast", cmd_broadcast))
    app.add_handler(CommandHandler("userinfo", cmd_userinfo))
    app.add_handler(CommandHandler("ban", cmd_ban))
    app.add_handler(CommandHandler("unban", cmd_unban))
    app.add_handler(CommandHandler("banned", cmd_banned))
    app.add_handler(CommandHandler("cancel", cancel))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("grant", cmd_grant))
    app.add_handler(CommandHandler("revoke", cmd_revoke))
    app.add_handler(CommandHandler("stop", cmd_stop))

    app.add_handler(CallbackQueryHandler(manage_callback, pattern=r"^(toggle_fb|fb_done|del_toggle|del_selected|del_all|confirm_del_marked|confirm_del_all|fb_cancel|sel_tpl|del_tpl|tpl_cancel)"))
    app.add_handler(CallbackQueryHandler(subscribe_plan_callback, pattern=r"^sub_plan:"))
    app.add_handler(CallbackQueryHandler(users_list_callback, pattern=r"^ausers:"))
    app.add_handler(CallbackQueryHandler(bulk_send_callback, pattern=r"^bsms:"))

    app.add_error_handler(error_handler)

    await app.initialize()
    await app.start()
    await app.updater.start_polling(drop_pending_updates=True, allowed_updates=Update.ALL_TYPES)

    try:
        await app.bot.set_my_commands([
            ("start", "Start bot & main menu"),
            ("help", "Show all commands"),
            ("cancel", "Cancel current action"),
            ("grant", "Owner: grant subscription (id days)"),
            ("revoke", "Owner: revoke subscription (id)"),
            ("broadcast", "Owner: broadcast message"),
            ("stats", "Owner: bot statistics"),
            ("userinfo", "Owner: user details"),
            ("ban", "Owner: ban user"),
            ("unban", "Owner: unban user"),
            ("banned", "Owner: banned list"),
        ])
        await app.bot.set_my_name(name="NUCLEAR Bulk SMS Bot")
        await app.bot.set_my_description(
            description=(
                "Bulk SMS Sender Bot — Firebase gateway phones se vehicles ko bulk SMS.\n"
                "Vehicle file upload karo, template banao, Firebase lagao aur bulk SMS bhejo.\n"
                "Har online phone 100 SMS/day."
            )
        )
        await app.bot.set_my_short_description(
            short_description="Bulk SMS via Firebase gateway phones. Owner-approval required."
        )
    except Exception as e:
        logger.warning(f"bot profile setup warning: {e}")

    logger.info("✅ Bulk SMS Bot running")

    stop_event = asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop_event.set)
        except NotImplementedError:
            pass
    await stop_event.wait()

    await app.updater.stop()
    await app.stop()
    await app.shutdown()
    logger.info("Bot stopped.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except RuntimeError as e:
        if "event loop is already running" in str(e).lower():
            loop = asyncio.get_event_loop()
            loop.create_task(main())
            try:
                loop.run_forever()
            except KeyboardInterrupt:
                pass
        else:
            raise